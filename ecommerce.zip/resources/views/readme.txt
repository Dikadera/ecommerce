composer require laravel/ui 
php artisan ui bootstrap --auth 
npm install
npm run dev