<!doctype html>
<html lang="en" data-layout="vertical" data-topbar="light" data-sidebar="light" data-sidebar-size="lg" data-sidebar-image="none" data-preloader="disable" data-body-image="none">

    <head>
        <base href="/public">
        <meta charset="utf-8">
        <title>Dashboard | Toner eCommerce + Admin HTML Template</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="eCommerce + Admin HTML Template" name="description">
        <meta content="Themesbrand" name="author">
        <!-- App favicon -->
        <link rel="shortcut icon" href="dashboard/assets/images/favicon.ico">

        <!-- jsvectormap css -->
        <link href="dashboard/assets/libs/jsvectormap/css/jsvectormap.min.css" rel="stylesheet" type="text/css">

        <!--Swiper slider css-->
        <link href="dashboard/assets/libs/swiper/swiper-bundle.min.css" rel="stylesheet" type="text/css">

        <!-- Layout config Js -->
        <script src="dashboard/assets/js/layout.js"></script>
        <!-- Bootstrap Css -->
        <link href="dashboard/assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <!-- Icons Css -->
        <link href="dashboard/assets/css/icons.min.css" rel="stylesheet" type="text/css">
        <!-- App Css-->
        <link href="dashboard/assets/css/app.min.css" rel="stylesheet" type="text/css">
        <!-- custom Css-->
        <link href="dashboard/assets/css/custom.min.css" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">

    </head>

    <body>

        <!-- Begin page -->
        <div id="layout-wrapper">
            
            <div class="top-tagbar">
    <div class="container-fluid">
        <div class="row justify-content-between align-items-center">
            <div class="col-md-4 col-9">
                <div class="fs-14 fw-medium">
                    <i class="bi bi-clock align-middle me-2"></i> <span id="current-time"></span>
                </div>
            </div>
            <div class="col-md-4 col-6 d-none d-xxl-block">
                <div class="d-flex align-items-center justify-content-center gap-3 fs-14 fw-medium">
                    <div>
                        <i class="bi bi-envelope align-middle me-2"></i> support@themesbrand.com
                    </div>
                    <div>
                        <i class="bi bi-globe align-middle me-2"></i> www.themesbrand.com
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-3">
                <div class="d-flex align-items-center justify-content-end gap-3 fs-14">
                    <a href="#!" class="text-reset fw-normal d-none d-lg-block">
                        Balance: <span class="fw-semibold">$8451.36</span>
                    </a>
                    <hr class="vr d-none d-lg-block">
                    <div class="dropdown topbar-head-dropdown topbar-tag-dropdown justify-content-end">
                        <button type="button" class="btn btn-icon btn-topbar text-reset rounded-circle fs-14 fw-medium" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img id="header-lang-img" src="dashboard/assets/images/flags/us.svg" alt="Header Language" height="16" class="rounded-circle me-2"> <span id="lang-name">English</span>
                        </button>
                        <div class="dropdown-menu dropdown-menu-end">
    
                            <!-- item-->
                            <a href="javascript:void(0);" class="dropdown-item notify-item language py-2" data-lang="en" title="English">
                                <img src="dashboard/assets/images/flags/us.svg" alt="user-image" class="me-2 rounded-circle" height="18">
                                <span class="align-middle">English</span>
                            </a>
    
                            <!-- item-->
                            <a href="javascript:void(0);" class="dropdown-item notify-item language" data-lang="sp" title="Spanish">
                                <img src="dashboard/assets/images/flags/spain.svg" alt="user-image" class="me-2 rounded-circle" height="18">
                                <span class="align-middle">Española</span>
                            </a>
    
                            <!-- item-->
                            <a href="javascript:void(0);" class="dropdown-item notify-item language" data-lang="gr" title="German">
                                <img src="dashboard/assets/images/flags/germany.svg" alt="user-image" class="me-2 rounded-circle" height="18"> <span class="align-middle">Deutsche</span>
                            </a>
    
                            <!-- item-->
                            <a href="javascript:void(0);" class="dropdown-item notify-item language" data-lang="it" title="Italian">
                                <img src="dashboard/assets/images/flags/italy.svg" alt="user-image" class="me-2 rounded-circle" height="18">
                                <span class="align-middle">Italiana</span>
                            </a>
    
                            <!-- item-->
                            <a href="javascript:void(0);" class="dropdown-item notify-item language" data-lang="ru" title="Russian">
                                <img src="dashboard/assets/images/flags/russia.svg" alt="user-image" class="me-2 rounded-circle" height="18">
                                <span class="align-middle">русский</span>
                            </a>
    
                            <!-- item-->
                            <a href="javascript:void(0);" class="dropdown-item notify-item language" data-lang="ch" title="Chinese">
                                <img src="dashboard/assets/images/flags/china.svg" alt="user-image" class="me-2 rounded-circle" height="18">
                                <span class="align-middle">中国人</span>
                            </a>
    
                            <!-- item-->
                            <a href="javascript:void(0);" class="dropdown-item notify-item language" data-lang="fr" title="French">
                                <img src="dashboard/assets/images/flags/french.svg" alt="user-image" class="me-2 rounded-circle" height="18">
                                <span class="align-middle">français</span>
                            </a>
    
                            <!-- item-->
                            <a href="javascript:void(0);" class="dropdown-item notify-item language" data-lang="sa" title="Arabic">
                                <img src="dashboard/assets/images/flags/sa.svg" alt="user-image" class="me-2 rounded-circle" height="18">
                                <span class="align-middle">عربى</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
            <header id="page-topbar">
                <div class="layout-width">
                    <div class="navbar-header">
                        <div class="d-flex">
                            <!-- LOGO -->
                            <div class="navbar-brand-box horizontal-logo">
                                <a href="/home" class="logo logo-dark">
                                    <span class="logo-sm">
                                        <img src="dashboard/assets/images/logo-sm.png" alt="" height="22">
                                    </span>
                                    <span class="logo-lg">
                                        <img src="dashboard/assets/images/logo-dark.png" alt="" height="25">
                                    </span>
                                </a>

                                <a href="/home" class="logo logo-light">
                                    <span class="logo-sm">
                                        <img src="dashboard/assets/images/logo-sm.png" alt="" height="22">
                                    </span>
                                    <span class="logo-lg">
                                        <img src="dashboard/assets/images/logo-light.png" alt="" height="25">
                                    </span>
                                </a>
                            </div>

                            <button type="button" class="btn btn-sm px-3 fs-16 header-item vertical-menu-btn topnav-hamburger" id="topnav-hamburger-icon">
                                <span class="hamburger-icon">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </span>
                            </button>

                            <button type="button" class="btn btn-sm px-3 fs-15 user-name-text header-item d-none d-md-block" data-bs-toggle="modal" data-bs-target="#searchModal">
                                <span class="bi bi-search me-2"></span> Search for Toner...
                            </button>
                        </div>

                        <div class="d-flex align-items-center">

                            <div class="d-md-none topbar-head-dropdown header-item">
                                <button type="button" class="btn btn-icon btn-topbar btn-ghost-dark rounded-circle" id="page-header-search-dropdown" data-bs-toggle="modal" data-bs-target="#searchModal">
                                    <i class="bi bi-search fs-16"></i>
                                </button>
                            </div>

                            <div class="dropdown topbar-head-dropdown ms-1 header-item dropdown-hover-end">
                                <button type="button" class="btn btn-icon btn-topbar btn-ghost-dark rounded-circle" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class='bi bi-grid fs-18'></i>
                                </button>
                                <div class="dropdown-menu dropdown-menu-lg p-0 dropdown-menu-end">
                                    <div class="p-3 border-top-0 border-start-0 border-end-0 border-dashed border">
                                        <div class="row align-items-center">
                                            <div class="col">
                                                <h6 class="m-0 fw-semibold fs-15"> Top Brands</h6>
                                            </div>
                                            <div class="col-auto">
                                                <a href="brands.html" class="btn btn-sm btn-soft-primary"> View All Brands
                                                    <i class="ri-arrow-right-s-line align-middle"></i></a>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="p-2">
                                        <div class="row g-0">
                                            <div class="col">
                                                <a class="dropdown-icon-item" href="#!">
                                                    <img src="dashboard/assets/images/brands/img-2.png" alt="Github">
                                                    <!-- <span>GitHub</span> -->
                                                </a>
                                            </div>
                                            <div class="col">
                                                <a class="dropdown-icon-item" href="#!">
                                                    <img src="dashboard/assets/images/brands/img-3.png" alt="Github">
                                                </a>
                                            </div>
                                            <div class="col">
                                                <a class="dropdown-icon-item" href="#!">
                                                    <img src="dashboard/assets/images/brands/img-13.png" alt="Github">
                                                </a>
                                            </div>
                                        </div>

                                        <div class="row g-0">
                                            <div class="col">
                                                <a class="dropdown-icon-item" href="#!">
                                                    <img src="dashboard/assets/images/brands/img-5.png" alt="Github">
                                                </a>
                                            </div>
                                            <div class="col">
                                                <a class="dropdown-icon-item" href="#!">
                                                    <img src="dashboard/assets/images/brands/img-6.png" alt="Github">
                                                </a>
                                            </div>
                                            <div class="col">
                                                <a class="dropdown-icon-item" href="#!">
                                                    <img src="dashboard/assets/images/brands/img-4.png" alt="Github">
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="dropdown topbar-head-dropdown ms-1 header-item dropdown-hover-end">
                                <button type="button" class="btn btn-icon btn-topbar btn-ghost-dark rounded-circle" id="page-header-cart-dropdown" data-bs-toggle="dropdown" data-bs-auto-close="outside" aria-haspopup="true" aria-expanded="false">
                                    <i class='bi bi-bag fs-18'></i>
                                    <span class="position-absolute topbar-badge cartitem-badge fs-10 translate-middle badge rounded-pill bg-info">5</span>
                                </button>
                                <div class="dropdown-menu dropdown-menu-xl dropdown-menu-end p-0 dropdown-menu-cart" aria-labelledby="page-header-cart-dropdown">
                                    <div class="p-3 border-top-0 border-start-0 border-end-0 border-dashed border">
                                        <div class="row align-items-center">
                                            <div class="col">
                                                <h6 class="m-0 fs-16 fw-semibold"> My Cart</h6>
                                            </div>
                                            <div class="col-auto">
                                                <span class="badge bg-info-subtle text-info  fs-13"><span class="cartitem-badge">7</span>
                                                    items</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div data-simplebar style="max-height: 300px;">
                                        <div class="p-2">
                                            <div class="text-center empty-cart" id="empty-cart">
                                                <div class="avatar-md mx-auto my-3">
                                                    <div class="avatar-title bg-info-subtle text-info fs-36 rounded-circle">
                                                        <i class='bx bx-cart'></i>
                                                    </div>
                                                </div>
                                                <h5 class="mb-3">Your Cart is Empty!</h5>
                                                <a href="apps-ecommerce-products.html" class="btn btn-success w-md mb-3">Shop Now</a>
                                            </div>
                                            <div class="d-block dropdown-item dropdown-item-cart text-wrap px-3 py-2">
                                                <div class="d-flex align-items-center">
                                                    <img src="dashboard/assets/images/products/img-1.png" class="me-3 rounded-circle avatar-sm p-2 bg-light" alt="user-pic">
                                                    <div class="flex-grow-1">
                                                        <h6 class="mt-0 mb-2 fs-15">
                                                            <a href="apps-ecommerce-product-details.html" class="text-reset">Branded
                                                                T-Shirts</a>
                                                        </h6>
                                                        <p class="mb-0 fs-13 text-muted">
                                                            Quantity: <span>10 x $32</span>
                                                        </p>
                                                    </div>
                                                    <div class="px-2">
                                                        <h5 class="m-0 fw-normal">$<span class="cart-item-price">320</span></h5>
                                                    </div>
                                                    <div class="ps-2">
                                                        <button type="button" class="btn btn-icon btn-sm btn-ghost-danger remove-item-btn"><i class="ri-close-fill fs-16"></i></button>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="d-block dropdown-item dropdown-item-cart text-wrap px-3 py-2">
                                                <div class="d-flex align-items-center">
                                                    <img src="dashboard/assets/images/products/img-2.png" class="me-3 rounded-circle avatar-sm p-2 bg-light" alt="user-pic">
                                                    <div class="flex-grow-1">
                                                        <h6 class="mt-0 mb-2 fs-15">
                                                            <a href="apps-ecommerce-product-details.html" class="text-reset">Bentwood Chair</a>
                                                        </h6>
                                                        <p class="mb-0 fs-13 text-muted">
                                                            Quantity: <span>5 x $18</span>
                                                        </p>
                                                    </div>
                                                    <div class="px-2">
                                                        <h5 class="m-0 fw-normal">$<span class="cart-item-price">89</span></h5>
                                                    </div>
                                                    <div class="ps-2">
                                                        <button type="button" class="btn btn-icon btn-sm btn-ghost-danger remove-item-btn"><i class="ri-close-fill fs-16"></i></button>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="d-block dropdown-item dropdown-item-cart text-wrap px-3 py-2">
                                                <div class="d-flex align-items-center">
                                                    <img src="dashboard/assets/images/products/img-3.png" class="me-3 rounded-circle avatar-sm p-2 bg-light" alt="user-pic">
                                                    <div class="flex-grow-1">
                                                        <h6 class="mt-0 mb-2 fs-15">
                                                            <a href="apps-ecommerce-product-details.html" class="text-reset">
                                                                Borosil Paper Cup</a>
                                                        </h6>
                                                        <p class="mb-0 fs-13 text-muted">
                                                            Quantity: <span>3 x $250</span>
                                                        </p>
                                                    </div>
                                                    <div class="px-2">
                                                        <h5 class="m-0 fw-normal">$<span class="cart-item-price">750</span></h5>
                                                    </div>
                                                    <div class="ps-2">
                                                        <button type="button" class="btn btn-icon btn-sm btn-ghost-danger remove-item-btn"><i class="ri-close-fill fs-16"></i></button>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="d-block dropdown-item dropdown-item-cart text-wrap px-3 py-2">
                                                <div class="d-flex align-items-center">
                                                    <img src="dashboard/assets/images/products/img-6.png" class="me-3 rounded-circle avatar-sm p-2 bg-light" alt="user-pic">
                                                    <div class="flex-grow-1">
                                                        <h6 class="mt-0 mb-2 fs-15">
                                                            <a href="apps-ecommerce-product-details.html" class="text-reset">Gray
                                                                Styled T-Shirt</a>
                                                        </h6>
                                                        <p class="mb-0 fs-13 text-muted">
                                                            Quantity: <span>1 x $1250</span>
                                                        </p>
                                                    </div>
                                                    <div class="px-2">
                                                        <h5 class="m-0 fw-normal">$ <span class="cart-item-price">1250</span></h5>
                                                    </div>
                                                    <div class="ps-2">
                                                        <button type="button" class="btn btn-icon btn-sm btn-ghost-danger remove-item-btn"><i class="ri-close-fill fs-16"></i></button>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="d-block dropdown-item dropdown-item-cart text-wrap px-3 py-2">
                                                <div class="d-flex align-items-center">
                                                    <img src="dashboard/assets/images/products/img-5.png" class="me-3 rounded-circle avatar-sm p-2 bg-light" alt="user-pic">
                                                    <div class="flex-grow-1">
                                                        <h6 class="mt-0 mb-2 fs-15">
                                                            <a href="apps-ecommerce-product-details.html" class="text-reset">Stillbird Helmet</a>
                                                        </h6>
                                                        <p class="mb-0 fs-13 text-muted">
                                                            Quantity: <span>2 x $495</span>
                                                        </p>
                                                    </div>
                                                    <div class="px-2">
                                                        <h5 class="m-0 fw-normal">$<span class="cart-item-price">990</span></h5>
                                                    </div>
                                                    <div class="ps-2">
                                                        <button type="button" class="btn btn-icon btn-sm btn-ghost-danger remove-item-btn"><i class="ri-close-fill fs-16"></i></button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="p-3 border-bottom-0 border-start-0 border-end-0 border-dashed border" id="checkout-elem">
                                        <div class="d-flex justify-content-between align-items-center pb-3">
                                            <h5 class="m-0 text-muted">Total:</h5>
                                            <div class="px-2">
                                                <h5 class="m-0" id="cart-item-total">$1258.58</h5>
                                            </div>
                                        </div>

                                        <a href="apps-ecommerce-checkout.html" class="btn btn-success text-center w-100">
                                            Checkout
                                        </a>
                                    </div>
                                </div>
                            </div>

                            <div class="ms-1 header-item d-none d-sm-flex">
                                <button type="button" class="btn btn-icon btn-topbar btn-ghost-dark rounded-circle" data-toggle="fullscreen">
                                    <i class='bi bi-arrows-fullscreen fs-16'></i>
                                </button>
                            </div>

                            <div class="dropdown topbar-head-dropdown ms-1 header-item dropdown-hover-end">
                                <button type="button" class="btn btn-icon btn-topbar btn-ghost-dark rounded-circle" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="bi bi-sun align-middle fs-20"></i>
                                </button>
                                <div class="dropdown-menu p-2 dropdown-menu-end" id="light-dark-mode">
                                    <a href="#!" class="dropdown-item" data-mode="light"><i class="bi bi-sun align-middle me-2"></i> Defualt (light mode)</a>
                                    <a href="#!" class="dropdown-item" data-mode="dark"><i class="bi bi-moon align-middle me-2"></i> Dark</a>
                                    <a href="#!" class="dropdown-item" data-mode="auto"><i class="bi bi-moon-stars align-middle me-2"></i> Auto (system defualt)</a>
                                </div>
                            </div>

                            <div class="dropdown topbar-head-dropdown ms-1 header-item dropdown-hover-end" id="notificationDropdown">
                                <button type="button" class="btn btn-icon btn-topbar btn-ghost-dark rounded-circle" id="page-header-notifications-dropdown" data-bs-toggle="dropdown"  data-bs-auto-close="outside" aria-haspopup="true" aria-expanded="false">
                                    <i class='bi bi-bell fs-18'></i>
                                    <span class="position-absolute topbar-badge fs-10 translate-middle badge rounded-pill bg-danger"><span class="notification-badge">4</span><span class="visually-hidden">unread messages</span></span>
                                </button>
                                <div class="dropdown-menu dropdown-menu-lg dropdown-menu-end p-0" aria-labelledby="page-header-notifications-dropdown">

                                    <div class="dropdown-head rounded-top">
                                        <div class="p-3 border-bottom border-bottom-dashed">
                                            <div class="row align-items-center">
                                                <div class="col">
                                                    <h6 class="mb-0 fs-16 fw-semibold"> Notifications <span class="badge bg-danger-subtle text-danger  fs-13 notification-badge"> 4</span></h6>
                                                    <p class="fs-14 text-muted mt-1 mb-0">You have <span class="fw-semibold notification-unread">3</span> unread messages</p>
                                                </div>
                                                <div class="col-auto dropdown">
                                                    <a href="javascript:void(0);" data-bs-toggle="dropdown" class="link-secondar2 fs-15"><i class="bi bi-three-dots-vertical"></i></a>
                                                    <ul class="dropdown-menu">
                                                        <li><a class="dropdown-item" href="#">All Clear</a></li>
                                                        <li><a class="dropdown-item" href="#">Mark all as read</a></li>
                                                        <li><a class="dropdown-item" href="#">Archive All</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>

                                    </div>

                                    <div class="py-2 ps-2" id="notificationItemsTabContent">
                                        <div data-simplebar style="max-height: 300px;" class="pe-2">
                                            <h6 class="text-overflow text-muted fs-13 my-2 text-uppercase notification-title">New</h6>
                                            <div class="text-reset notification-item d-block dropdown-item position-relative unread-message">
                                                <div class="d-flex">
                                                    <div class="avatar-xs me-3 flex-shrink-0">
                                                        <span class="avatar-title bg-info-subtle text-info rounded-circle fs-16">
                                                            <i class="bx bx-badge-check"></i>
                                                        </span>
                                                    </div>
                                                    <div class="flex-grow-1">
                                                        <a href="#!" class="stretched-link">
                                                            <h6 class="mt-0 fs-14 mb-2 lh-base">Your <b>Elite</b> author Graphic
                                                                Optimization <span class="text-secondary">reward</span> is ready!
                                                            </h6>
                                                        </a>
                                                        <p class="mb-0 fs-11 fw-medium text-uppercase text-muted">
                                                            <span><i class="mdi mdi-clock-outline"></i> Just 30 sec ago</span>
                                                        </p>
                                                    </div>
                                                    <div class="px-2 fs-15">
                                                        <div class="form-check notification-check">
                                                            <input class="form-check-input" type="checkbox" value="" id="all-notification-check01">
                                                            <label class="form-check-label" for="all-notification-check01"></label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="text-reset notification-item d-block dropdown-item position-relative unread-message">
                                                <div class="d-flex">
                                                    <div class="position-relative me-3 flex-shrink-0">
                                                        <img src="dashboard/assets/images/users/avatar-2.jpg" class="rounded-circle avatar-xs" alt="user-pic">
                                                        <span class="active-badge position-absolute start-100 translate-middle p-1 bg-success rounded-circle">
                                                            <span class="visually-hidden">New alerts</span>
                                                        </span>
                                                    </div>
                                                    <div class="flex-grow-1">
                                                        <a href="#!" class="stretched-link">
                                                            <h6 class="mt-0 mb-1 fs-14 fw-semibold">Angela Bernier</h6>
                                                        </a>
                                                        <div class="fs-13 text-muted">
                                                            <p class="mb-1">Answered to your comment on the cash flow forecast's graph 🔔.</p>
                                                        </div>
                                                        <p class="mb-0 fs-11 fw-medium text-uppercase text-muted">
                                                            <span><i class="mdi mdi-clock-outline"></i> 48 min ago</span>
                                                        </p>
                                                    </div>
                                                    <div class="px-2 fs-15">
                                                        <div class="form-check notification-check">
                                                            <input class="form-check-input" type="checkbox" value="" id="all-notification-check02">
                                                            <label class="form-check-label" for="all-notification-check02"></label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="text-reset notification-item d-block dropdown-item position-relative unread-message">
                                                <div class="d-flex">
                                                    <div class="avatar-xs me-3 flex-shrink-0">
                                                        <span class="avatar-title bg-danger-subtle text-danger rounded-circle fs-16">
                                                            <i class='bx bx-message-square-dots'></i>
                                                        </span>
                                                    </div>
                                                    <div class="flex-grow-1">
                                                        <a href="#!" class="stretched-link">
                                                            <h6 class="mt-0 mb-2 fs-14 lh-base">You have received <b class="text-success">20</b> new messages in the conversation
                                                            </h6>
                                                        </a>
                                                        <p class="mb-0 fs-11 fw-medium text-uppercase text-muted">
                                                            <span><i class="mdi mdi-clock-outline"></i> 2 hrs ago</span>
                                                        </p>
                                                    </div>
                                                    <div class="px-2 fs-15">
                                                        <div class="form-check notification-check">
                                                            <input class="form-check-input" type="checkbox" value="" id="all-notification-check03">
                                                            <label class="form-check-label" for="all-notification-check03"></label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <h6 class="text-overflow text-muted fs-13 my-2 text-uppercase notification-title">Read Before</h6>

                                            <div class="text-reset notification-item d-block dropdown-item position-relative">
                                                <div class="d-flex">

                                                    <div class="position-relative me-3 flex-shrink-0">
                                                        <img src="dashboard/assets/images/users/avatar-8.jpg" class="rounded-circle avatar-xs" alt="user-pic">
                                                        <span class="active-badge position-absolute start-100 translate-middle p-1 bg-warning rounded-circle">
                                                            <span class="visually-hidden">New alerts</span>
                                                        </span>
                                                    </div>

                                                    <div class="flex-grow-1">
                                                        <a href="#!" class="stretched-link">
                                                            <h6 class="mt-0 mb-1 fs-14 fw-semibold">Maureen Gibson</h6>
                                                        </a>
                                                        <div class="fs-13 text-muted">
                                                            <p class="mb-1">We talked about a project on linkedin.</p>
                                                        </div>
                                                        <p class="mb-0 fs-11 fw-medium text-uppercase text-muted">
                                                            <span><i class="mdi mdi-clock-outline"></i> 4 hrs ago</span>
                                                        </p>
                                                    </div>
                                                    <div class="px-2 fs-15">
                                                        <div class="form-check notification-check">
                                                            <input class="form-check-input" type="checkbox" value="" id="all-notification-check04">
                                                            <label class="form-check-label" for="all-notification-check04"></label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="notification-actions" id="notification-actions">
                                            <div class="d-flex text-muted justify-content-center align-items-center">
                                                Select <div id="select-content" class="text-body fw-semibold px-1">0</div> Result <button type="button" class="btn btn-link link-danger p-0 ms-2" data-bs-toggle="modal" data-bs-target="#removeNotificationModal">Remove</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="dropdown ms-sm-3 header-item topbar-user topbar-head-dropdown dropdown-hover-end">
                                <button type="button" class="btn" id="page-header-user-dropdown" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <span class="d-flex align-items-center">
                                        <img class="rounded-circle header-profile-user" src="dashboard/assets/images/users/avatar-1.jpg" alt="Header Avatar">
                                        <span class="text-start ms-xl-2">
                                            <span class="d-none d-xl-inline-block ms-1 fw-medium user-name-text">Raquel Murillo</span>
                                            <span class="d-none d-xl-block ms-1 fs-13 user-name-sub-text">Founder</span>
                                        </span>
                                    </span>
                                </button>
                                <div class="dropdown-menu dropdown-menu-end">
                                    <!-- item-->
                                    <h6 class="dropdown-header">Welcome Raquel!</h6>
                                    <a class="dropdown-item" href="account.html"><i class="bi bi-person-circle text-muted fs-15 align-middle me-1"></i> <span class="align-middle">Profile</span></a>
                                    <a class="dropdown-item" href="calendar.html"><i class="bi bi-cart4 text-muted fs-15 align-middle me-1"></i> <span class="align-middle">Order Track</span></a>
                                    <a class="dropdown-item" href="product-list.html"><i class="bi bi-box-seam text-muted fs-15 align-middle me-1"></i> <span class="align-middle">Products</span></a>
                                    <a class="dropdown-item" href="dashboard/frontend/index.html"><span class="badge bg-success-subtle text-success float-end ms-2">New</span><i class="bi bi-cassette text-muted fs-15 align-middle me-1"></i> <span class="align-middle">Frontend</span></a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item" href="account-settings.html"><i class="bi bi-gear text-muted fs-15 align-middle me-1"></i> <span class="align-middle">Settings</span></a>
                                    <a class="dropdown-item" href="auth-logout-basic.html"><i class="bi bi-box-arrow-right text-muted fs-15 align-middle me-1"></i> <span class="align-middle" data-key="t-logout">Logout</span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>


            <!-- Modal -->
            <div class="modal fade" id="searchModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content rounded">
                        <div class="modal-header p-3">
                            <div class="position-relative w-100">
                                <input type="text" class="form-control form-control-lg border-2" placeholder="Search for Toner..." autocomplete="off" id="search-options" value="">
                                <span class="bi bi-search search-widget-icon fs-17"></span>
                                <a href="javascript:void(0);" class="search-widget-icon fs-14 link-secondary text-decoration-underline search-widget-icon-close d-none" id="search-close-options">Clear</a>
                            </div>
                        </div>
                        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-end p-0 overflow-hidden" id="search-dropdown">

                            <div class="dropdown-head rounded-top">
                                <div class="p-3">
                                    <div class="row align-items-center">
                                        <div class="col">
                                            <h6 class="m-0 fs-14 text-muted fw-semibold"> RECENT SEARCHES </h6>
                                        </div>
                                    </div>
                                </div>

                                <div class="dropdown-item bg-transparent text-wrap">
                                    <a href="index.html" class="btn btn-soft-secondary btn-sm btn-rounded">how to setup <i class="mdi mdi-magnify ms-1 align-middle"></i></a>
                                    <a href="index.html" class="btn btn-soft-secondary btn-sm btn-rounded">buttons <i class="mdi mdi-magnify ms-1 align-middle"></i></a>
                                </div>
                            </div>

                            <div data-simplebar style="max-height: 300px;" class="pe-2 ps-3 mt-3">
                                <div class="list-group list-group-flush border-dashed">
                                    <div class="notification-group-list">
                                        <h5 class="text-overflow text-muted fs-13 mb-2 mt-3 text-uppercase notification-title">Apps Pages</h5>
                                        <a href="javascript:void(0);" class="list-group-item dropdown-item notify-item"><i class="bi bi-speedometer2 me-2"></i> <span>Analytics Dashboard</span></a>
                                        <a href="javascript:void(0);" class="list-group-item dropdown-item notify-item"><i class="bi bi-filetype-psd me-2"></i> <span>Toner.psd</span></a>
                                        <a href="javascript:void(0);" class="list-group-item dropdown-item notify-item"><i class="bi bi-ticket-detailed me-2"></i> <span>Support Tickets</span></a>
                                        <a href="javascript:void(0);" class="list-group-item dropdown-item notify-item"><i class="bi bi-file-earmark-zip me-2"></i> <span>Toner.zip</span></a>
                                    </div>
                        
                                    <div class="notification-group-list">
                                        <h5 class="text-overflow text-muted fs-13 mb-2 mt-3 text-uppercase notification-title">Links</h5>
                                        <a href="javascript:void(0);" class="list-group-item dropdown-item notify-item"><i class="bi bi-link-45deg me-2 align-middle"></i> <span>www.themesbrand.com</span></a>
                                    </div>

                                    <div class="notification-group-list">
                                        <h5 class="text-overflow text-muted fs-13 mb-2 mt-3 text-uppercase notification-title">People</h5>
                                        <a href="javascript:void(0);" class="list-group-item dropdown-item notify-item">
                                            <div class="d-flex align-items-center">
                                                <img src="dashboard/assets/images/users/avatar-1.jpg" alt="" class="avatar-xs rounded-circle flex-shrink-0 me-2">
                                                <div>
                                                    <h6 class="mb-0">Ayaan Bowen</h6>
                                                    <span class="fs-12 text-muted">React Developer</span>
                                                </div>
                                            </div>
                                        </a>
                                        <a href="javascript:void(0);" class="list-group-item dropdown-item notify-item">
                                            <div class="d-flex align-items-center">
                                                <img src="dashboard/assets/images/users/avatar-7.jpg" alt="" class="avatar-xs rounded-circle flex-shrink-0 me-2">
                                                <div>
                                                    <h6 class="mb-0">Alexander Kristi</h6>
                                                    <span class="fs-12 text-muted">React Developer</span>
                                                </div>
                                            </div>
                                        </a>
                                        <a href="javascript:void(0);" class="list-group-item dropdown-item notify-item">
                                            <div class="d-flex align-items-center">
                                                <img src="dashboard/assets/images/users/avatar-5.jpg" alt="" class="avatar-xs rounded-circle flex-shrink-0 me-2">
                                                <div>
                                                    <h6 class="mb-0">Alan Carla</h6>
                                                    <span class="fs-12 text-muted">React Developer</span>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- removeNotificationModal -->
            <div id="removeNotificationModal" class="modal fade zoomIn" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" id="NotificationModalbtn-close"></button>
                        </div>
                        <div class="modal-body p-md-5">
                            <div class="text-center">
                                <div class="text-danger">
                                    <i class="bi bi-trash display-4"></i>
                                </div>
                                <div class="mt-4 fs-15">
                                    <h4 class="mb-1">Are you sure ?</h4>
                                    <p class="text-muted mx-4 mb-0">Are you sure you want to remove this Notification ?</p>
                                </div>
                            </div>
                            <div class="d-flex gap-2 justify-content-center mt-4 mb-2">
                                <button type="button" class="btn w-sm btn-light" data-bs-dismiss="modal">Close</button>
                                <button type="button" class="btn w-sm btn-danger" id="delete-notification">Yes, Delete It!</button>
                            </div>
                        </div>

                    </div><!-- /.modal-content -->
                </div><!-- /.modal-dialog -->
            </div><!-- /.modal -->
            <!-- ========== App Menu ========== -->
            <div class="app-menu navbar-menu">
                <!-- LOGO -->
                <div class="navbar-brand-box">
                    <a href="index.html" class="logo logo-dark">
                        <span class="logo-sm">
                            <img src="dashboard/assets/images/logo-sm.png" alt="" height="26">
                        </span>
                        <span class="logo-lg">
                            <img src="dashboard/assets/images/logo-dark.png" alt="" height="26">
                        </span>
                    </a>
                    <a href="index.html" class="logo logo-light">
                        <span class="logo-sm">
                            <img src="dashboard/assets/images/logo-sm.png" alt="" height="24">
                        </span>
                        <span class="logo-lg">
                            <img src="dashboard/assets/images/logo-light.png" alt="" height="24">
                        </span>
                    </a>
                    <button type="button" class="btn btn-sm p-0 fs-20 header-item float-end btn-vertical-sm-hover" id="vertical-hover">
                        <i class="ri-record-circle-line"></i>
                    </button>
                </div>

                <div id="scrollbar">
                    <div class="container-fluid">

                        <div id="two-column-menu">
                        </div>
                        <ul class="navbar-nav" id="navbar-nav">
                            <li class="menu-title"><span data-key="t-menu">Menu</span></li>
                            <li class="nav-item">
                                <a href="index.html" class="nav-link menu-link"> <i class="bi bi-speedometer2"></i> <span data-key="t-dashboard">Dashboard</span> <span class="badge badge-pill bg-danger-subtle text-danger " data-key="t-hot">Hot</span></a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link menu-link" href="#sidebarProducts" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="sidebarProducts">
                                    <i class="bi bi-box-seam"></i> <span data-key="t-products">Products</span>
                                </a>
                                <div class="collapse menu-dropdown" id="sidebarProducts">
                                    <ul class="nav nav-sm flex-column">
                                        <li class="nav-item">
                                            <a href="product-list.html" class="nav-link" data-key="t-list-view">List View</a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="product-grid.html" class="nav-link" data-key="t-grid-view">Grid View</a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="product-overview.html" class="nav-link" data-key="t-overview">Overview</a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="product-create.html" class="nav-link" data-key="t-create-product">Create Product</a>
                                        </li>
                                        <li class="nav-item">       
                                            <a href="categories.html" class="nav-link" data-key="t-categories">Categories</a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="sub-categories.html" class="nav-link" data-key="t-sub-categories">Sub Categories</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link menu-link" href="#sidebarOrders" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="sidebarOrders">
                                    <i class="bi bi-cart4"></i> <span data-key="t-orders">Orders</span>
                                </a>
                                <div class="collapse menu-dropdown" id="sidebarOrders">
                                    <ul class="nav nav-sm flex-column">
                                        <li class="nav-item">
                                            <a href="orders-list-view.html" class="nav-link" data-key="t-list-view">List View</a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="orders-overview.html" class="nav-link" data-key="t-overview">Overview</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>

                            <li class="nav-item">
                                <a href="calendar.html" class="nav-link menu-link"><i class="bi bi-calendar-week"></i> <span data-key="t-calendar">Calendar</span> </a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link menu-link" href="#sidebarSellers" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="sidebarSellers">
                                    <i class="bi bi-binoculars"></i> <span data-key="t-sellers">Sellers</span>
                                </a>
                                <div class="collapse menu-dropdown" id="sidebarSellers">
                                    <ul class="nav nav-sm flex-column">
                                        <li class="nav-item">
                                            <a href="sellers-list-view.html" class="nav-link" data-key="t-list-view">List View</a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="sellers-grid-view.html" class="nav-link" data-key="t-grid-view">Grid View</a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="seller-overview.html" class="nav-link" data-key="t-overview">Overview</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link menu-link" href="#sidebarInvoice" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="sidebarInvoice">
                                    <i class="bi bi-archive"></i> <span data-key="t-invoice">Invoice</span>
                                </a>
                                <div class="collapse menu-dropdown" id="sidebarInvoice">
                                    <ul class="nav nav-sm flex-column">
                                        <li class="nav-item">
                                            <a href="invoices-list.html" class="nav-link" data-key="t-list-view">List View</a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="invoices-details.html" class="nav-link" data-key="t-overview">Overview</a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="invoices-create.html" class="nav-link" data-key="t-create-invoice">Create Invoice</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>

                            <li class="nav-item">
                                <a href="users-list.html" class="nav-link menu-link"> <i class="bi bi-person-bounding-box"></i> <span data-key="t-users-list">Users List</span> </a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link menu-link" href="#sidebarShipping" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="sidebarShipping">
                                    <i class="bi bi-truck"></i> <span data-key="t-shipping">Shipping</span>
                                </a>
                                <div class="collapse menu-dropdown" id="sidebarShipping">
                                    <ul class="nav nav-sm flex-column">
                                        <li class="nav-item">
                                            <a href="shipping-list.html" class="nav-link" data-key="t-shipping-list">Shipping List</a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="shipments.html" class="nav-link" data-key="t-shipments">Shipments</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a href="coupons.html" class="nav-link menu-link"> <i class="bi bi-tag"></i> <span data-key="t-coupons">Coupons</span> </a>
                            </li>   
                            <li class="nav-item">
                                <a href="reviews-ratings.html" class="nav-link menu-link"><i class="bi bi-star"></i> <span data-key="t-reviews-ratings">Reviews & Ratings</span></a>
                            </li>
                            <li class="nav-item">
                                <a href="brands.html" class="nav-link menu-link"><i class="bi bi-shop"></i> <span data-key="t-brands">Brands</span> </a>
                            </li>
                            <li class="nav-item">
                                <a href="statistics.html" class="nav-link menu-link"><i class="bi bi-pie-chart"></i> <span data-key="t-statistics">Statistics</span> </a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link menu-link" href="#sidebarLocalization" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="sidebarLocalization">
                                    <i class="bi bi-coin"></i> <span data-key="t-localization">Localization</span>
                                </a>
                                <div class="collapse menu-dropdown" id="sidebarLocalization">
                                    <ul class="nav nav-sm flex-column">
                                        <li class="nav-item">
                                            <a href="transactions.html" class="nav-link" data-key="t-transactions">Transactions</a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="currency-rates.html" class="nav-link" data-key="t-currency-rates">Currency Rates</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link menu-link" href="#sidebarAccounts" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="sidebarAccounts">
                                    <i class="bi bi-person-circle"></i> <span data-key="t-accounts">Accounts</span>
                                </a>
                                <div class="collapse menu-dropdown" id="sidebarAccounts">
                                    <ul class="nav nav-sm flex-column">
                                        <li class="nav-item">
                                            <a href="account.html" class="nav-link" data-key="t-my-account">My Account</a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="account-settings.html" class="nav-link" data-key="t-settings">Settings</a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="auth-signup-basic.html" class="nav-link" data-key="t-sign-up">Sign Up</a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="auth-signin-basic.html" class="nav-link" data-key="t-sign-in">Sign In</a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="auth-pass-reset-basic.html" class="nav-link" data-key="t-passowrd-reset">Password Reset</a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="auth-pass-change-basic.html" class="nav-link" data-key="t-create-password">Password Create</a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="auth-success-msg-basic.html" class="nav-link" data-key="t-success-message">Success Message</a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="auth-twostep-basic.html" class="nav-link" data-key="t-two-step-verify">Two Step Verify</a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="auth-logout-basic.html" class="nav-link" data-key="t-logout">Logout</a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="auth-404.html" class="nav-link" data-key="t-error-404">Error 404</a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="auth-500.html" class="nav-link" data-key="t-error-500">Error 500</a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="coming-soon.html" class="nav-link" data-key="t-coming-soon">Coming Soon</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link menu-link" href="dashboard/components/index.html" target="_blank">
                                    <i class="bi bi-layers"></i> <span data-key="t-components">Components</span> <span class="badge badge-pill bg-secondary" data-key="t-v1.0">v1.0</span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link menu-link" href="#sidebarMultilevel" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="sidebarMultilevel">
                                    <i class="bi bi-share"></i> <span data-key="t-multi-level">Multi Level</span>
                                </a>
                                <div class="collapse menu-dropdown" id="sidebarMultilevel">
                                    <ul class="nav nav-sm flex-column">
                                        <li class="nav-item">
                                            <a href="#" class="nav-link" data-key="t-level-1.1"> Level 1.1 </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="#sidebarAccount" class="nav-link" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="sidebarAccount" data-key="t-level-1.2"> Level
                                                1.2
                                            </a>
                                            <div class="collapse menu-dropdown" id="sidebarAccount">
                                                <ul class="nav nav-sm flex-column">
                                                    <li class="nav-item">
                                                        <a href="#" class="nav-link" data-key="t-level-2.1"> Level 2.1 </a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a href="#sidebarCrm" class="nav-link" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="sidebarCrm" data-key="t-level-2.2"> Level 2.2
                                                        </a>
                                                        <div class="collapse menu-dropdown" id="sidebarCrm">
                                                            <ul class="nav nav-sm flex-column">
                                                                <li class="nav-item">
                                                                    <a href="#" class="nav-link" data-key="t-level-3.1"> Level 3.1
                                                                    </a>
                                                                </li>
                                                                <li class="nav-item">
                                                                    <a href="#" class="nav-link" data-key="t-level-3.2"> Level 3.2
                                                                    </a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </li>

                        </ul>
                    </div>
                    <!-- Sidebar -->
                </div>

                <div class="sidebar-background"></div>
            </div>
            <!-- Left Sidebar End -->
            <!-- Vertical Overlay-->
            <div class="vertical-overlay"></div>
            
            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">
                
                <div class="page-content">
                    <div class="container-fluid">

                        <div class="row">
                            <div class="col-xxl-12 col-lg-6 order-first">
                                <div class="row row-cols-xxl-4 row-cols-1">
                                    <div class="col">
                                        <!-- card -->
                                        <div class="card card-animate">
                                            <div class="card-body">
                                                <div class="d-flex justify-content-between">
                                                    <div class="vr rounded bg-secondary opacity-50" style="width: 4px;"></div>
                                                    <div class="flex-grow-1 ms-3">
                                                        <p class="text-uppercase fw-medium text-muted fs-14 text-truncate">Total Earnings</p>
                                                        <h4 class="fs-22 fw-semibold mb-3">$<span class="counter-value" data-target="98851.35">0</span></h4>
                                                        <div class="d-flex align-items-center gap-2">
                                                            <h5 class="badge bg-success-subtle text-success  mb-0">
                                                                <i class="ri-arrow-right-up-line align-bottom"></i> +18.30 %
                                                            </h5>
                                                            <p class="text-muted mb-0">than last week</p>
                                                        </div>
                                                    </div>
                                                    <div class="avatar-sm flex-shrink-0">
                                                        <span class="avatar-title bg-secondary-subtle text-secondary rounded fs-3">
                                                            <i class="ph-wallet"></i>
                                                        </span>
                                                    </div>
                                                </div>
                                            </div><!-- end card body -->
                                        </div><!-- end card -->
                                    </div><!-- end col -->
                            
                                    <div class="col">
                                        <!-- card -->
                                        <div class="card card-animate">
                                            <div class="card-body">
                                                <div class="d-flex justify-content-between">
                                                    <div class="vr rounded bg-info opacity-50" style="width: 4px;"></div>
                                                    <div class="flex-grow-1 ms-3">
                                                        <p class="text-uppercase fw-medium text-muted fs-14 text-truncate">Orders</p>
                                                        <h4 class="fs-22 fw-semibold mb-3"><span class="counter-value" data-target="65802">0</span> </h4>
                                                        <div class="d-flex align-items-center gap-2">
                                                            <h5 class="badge bg-danger-subtle text-danger  mb-0">
                                                                <i class="ri-arrow-right-down-line align-bottom"></i> -2.74 %
                                                            </h5>
                                                            <p class="text-muted mb-0">than last week</p>
                                                        </div>
                                                    </div>
                                                    <div class="avatar-sm flex-shrink-0">
                                                        <span class="avatar-title bg-info-subtle text-info rounded fs-3">
                                                            <i class="ph-storefront"></i>
                                                        </span>
                                                    </div>
                                                </div>
                                            </div><!-- end card body -->
                                        </div><!-- end card -->
                                    </div><!-- end col -->
                            
                                    <div class="col">
                                        <!-- card -->
                                        <div class="card card-animate">
                                            <div class="card-body">
                                                <div class="d-flex justify-content-between">
                                                    <div class="vr rounded bg-warning opacity-50" style="width: 4px;"></div>
                                                    <div class="flex-grow-1 ms-3">
                                                        <p class="text-uppercase fw-medium text-muted fs-14 text-truncate">Customers</p>
                                                        <h4 class="fs-22 fw-semibold mb-3"><span class="counter-value" data-target="79958">0</span> </h4>
                                                        <div class="d-flex align-items-center gap-2">
                                                            <h5 class="badge bg-success-subtle text-success  mb-0">
                                                                <i class="ri-arrow-right-up-line align-bottom"></i> +29.08 %
                                                            </h5>
                                                            <p class="text-muted mb-0">than last week</p>
                                                        </div>
                                                    </div>
                                                    <div class="avatar-sm flex-shrink-0">
                                                        <span class="avatar-title bg-warning-subtle text-warning rounded fs-3">
                                                            <i class="ph-user-circle"></i>
                                                        </span>
                                                    </div>
                                                </div>
                                            </div><!-- end card body -->
                                        </div><!-- end card -->
                                    </div><!-- end col -->
                                    <div class="col">
                                        <!-- card -->
                                        <div class="card card-animate">
                                            <div class="card-body">
                                                <div class="d-flex justify-content-between">
                                                    <div class="vr rounded bg-primary opacity-50" style="width: 4px;"></div>
                                                    <div class="flex-grow-1 ms-3">
                                                        <p class="text-uppercase fw-medium text-muted fs-14 text-truncate">Products</p>
                                                        <h4 class="fs-22 fw-semibold mb-3"><span class="counter-value" data-target="36758">0</span> </h4>
                                                        <div class="d-flex align-items-center gap-2">
                                                            <h5 class="badge bg-success-subtle text-success  mb-0">
                                                                <i class="ri-arrow-right-up-line align-bottom"></i> +1.67 %
                                                            </h5>
                                                            <p class="text-muted mb-0">than last week</p>
                                                        </div>
                                                    </div>
                                                    <div class="avatar-sm flex-shrink-0">
                                                        <span class="avatar-title bg-primary-subtle text-primary rounded fs-3">
                                                            <i class="ph-sketch-logo"></i>
                                                        </span>
                                                    </div>
                                                </div>
                                            </div><!-- end card body -->
                                        </div><!-- end card -->
                                    </div><!-- end col -->
                                </div> <!-- end row-->
                            </div><!--end col-->

                            <div class="col-xxl-9 order-last">
                                <div class="card">
                                    <div class="card-header align-items-center d-flex">
                                        <h4 class="card-title mb-0 flex-grow-1">Revenue</h4>
                                        <div>
                                            <button type="button" class="btn btn-soft-secondary btn-sm">
                                                ALL
                                            </button>
                                            <button type="button" class="btn btn-soft-secondary btn-sm">
                                                1M
                                            </button>
                                            <button type="button" class="btn btn-soft-secondary btn-sm">
                                                6M
                                            </button>
                                            <button type="button" class="btn btn-soft-primary btn-sm">
                                                1Y
                                            </button>
                                        </div>
                                    </div><!-- end card header -->
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-xxl-8">
                                                <div id="line_chart_datalabel" data-colors='["--tb-secondary", "--tb-danger", "--tb-success"]' class="apex-charts" dir="ltr"></div>
                                            </div>
                                            <div class="col-xxl-4">
                                                <div class="d-flex align-items-center gap-3 mb-4 mt-3 mt-xxl-0">
                                                    <div class="input-group">
                                                        <input type="text" class="form-control" data-provider="flatpickr" data-range-date="true" data-date-format="d M, Y" data-deafult-date="01 Jan 2022 to 31 Jan 2022" readonly="readonly">
                                                        <div class="input-group-text bg-primary border-primary text-white">
                                                            <i class="ri-calendar-2-line"></i>
                                                        </div>
                                                    </div>
                                                    <div class="dropdown flex-shrink-0">
                                                        <a class="text-reset dropdown-btn d-inline-block" href="#" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                            <span class="text-muted">Report<i class="mdi mdi-chevron-down ms-1"></i></span>
                                                        </a>
                                                        <div class="dropdown-menu dropdown-menu-end">
                                                            <a class="dropdown-item" href="#">Download Report</a>
                                                            <a class="dropdown-item" href="#">Export</a>
                                                            <a class="dropdown-item" href="#">Import</a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row g-0 text-center">
                                                    <div class="col-6 col-sm-6">
                                                        <div class="p-3 border border-dashed border-bottom-0">
                                                            <h5 class="mb-1"><span class="counter-value" data-target="65802">0</span></h5>
                                                            <p class="text-muted mb-0">Orders</p>
                                                        </div>
                                                    </div>
                                                    <!--end col-->
                                                    <div class="col-6 col-sm-6">
                                                        <div class="p-3 border border-dashed border-start-0 border-bottom-0">
                                                            <h5 class="mb-1">$<span class="counter-value" data-target="98851.35">0</span>k</h5>
                                                            <p class="text-muted mb-0">Earnings</p>
                                                        </div>
                                                    </div>
                                                    <!--end col-->
                                                    <div class="col-6 col-sm-6">
                                                        <div class="p-3 border border-dashed">
                                                            <h5 class="mb-1"><span class="counter-value" data-target="2450">0</span></h5>
                                                            <p class="text-muted mb-0">Refunds</p>
                                                        </div>
                                                    </div>
                                                    <!--end col-->
                                                    <div class="col-6 col-sm-6">
                                                        <div class="p-3 border border-dashed border-start-0">
                                                            <h5 class="mb-1 text-success"><span class="counter-value" data-target="18.92">0</span>%</h5>
                                                            <p class="text-muted mb-0">Conversation Ratio</p>
                                                        </div>
                                                    </div>
                                                    <!--end col-->
                                                </div><!--end row-->

                                                <div class="card mt-4 mb-0 bg-info-subtle border-0">
                                                    <div class="card-body">
                                                        <h5 class="fs-16">Reached 5k Customers</h5>
                                                        <p class="text-muted">Hey! Awesome products! Can you share the best product name ?</p>
                                                        <a href="statistics.html" class="btn btn-info btn-sm">See Report <i class="bi bi-arrow-right ms-1 align-middle"></i></a>
                                                    </div>
                                                </div>
                                            </div><!--end col-->
                                        </div><!--end row-->
                                    </div><!-- end card body -->
                                </div><!-- end card -->
                                <div class="card overflow-hidden">
                                    <div class="position-absolute opacity-50 start-0 end-0 top-0 bottom-0" style="background-image: url('dashboard/assets/images/sidebar/body-light-1.png');"></div>
                                    <div class="card-body d-flex justify-content-between align-items-center z-1">
                                        <div class="d-flex align-items-center gap-3">
                                            <div class="flex-shrink-0">
                                                <i class="ph-storefront display-6"></i>
                                            </div>
                                            <div class="flex-grow-1">
                                                <h5 class="card-title fw-medium fs-17 mb-1">Have you tried new <b>Toner eCommerce Templates</b> ?</h5>
                                                <p class="mb-0">That allows customers to browse and purchase items from an online store.</p>
                                            </div>
                                        </div>
                                        <div>
                                            <a href="product-create.html" class="btn btn-success btn-label btn-hover rounded-pill"><i class="bi bi-box-seam label-icon align-middle rounded-pill fs-16 me-2"></i> Add New Product</a>
                                        </div>
                                    </div>
                                </div>
                                <!-- end card -->
                            </div><!-- end col -->
                            <div class="col-xxl-3 col-lg-6 order-0 order-xxl-last">
                                <div class="card card-height-100">
                                    <div class="card-header">
                                        <div class="d-flex align-items-center">
                                            <h6 class="card-title flex-grow-1 mb-0">Top Sales Location</h6>
                                            <div class="flex-shrink-0">
                                                <div class="dropdown card-header-dropdown">
                                                    <a class="text-reset dropdown-btn" href="#" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        <span class="text-muted">Report<i class="mdi mdi-chevron-down ms-1"></i></span>
                                                    </a>
                                                    <div class="dropdown-menu dropdown-menu-end">
                                                        <a class="dropdown-item" href="#">Download Report</a>
                                                        <a class="dropdown-item" href="#">Export</a>
                                                        <a class="dropdown-item" href="#">Import</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <div id="world-map-line-markers" data-colors='["--tb-light"]' style="height: 255px"></div>

                                        <div class="mt-4">
                                            <h4 class="mb-1">65,802 <small class="fw-normal fs-14">Total Sales</small></h4>
                                            <p class="text-muted">Sales from Jan - Dec 2022</p>
                                        </div>
                                        
                                        <div class="table-responsive table-card mt-3">
                                            <table class="table table-borderless table-striped align-middle table-sm fs-14 mb-0">
                                                <tbody>
                                                    <tr>
                                                        <td>
                                                            <div class="d-flex align-items-center gap-2">
                                                                <div>
                                                                    <img src="dashboard/assets/images/flags/us.svg" alt="" height="18" class="rounded-circle">
                                                                </div>
                                                                <h6 class="fw-medium fs-14 mb-0">United States</h6>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            23410
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <div class="d-flex align-items-center gap-2">
                                                                <div>
                                                                    <img src="dashboard/assets/images/flags/gl.svg" alt="" height="18" class="rounded-circle">
                                                                </div>
                                                                <h6 class="fw-medium fs-14 mb-0">Greenland</h6>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            19520
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <div class="d-flex align-items-center gap-2">
                                                                <div>
                                                                    <img src="dashboard/assets/images/flags/br.svg" alt="" height="18" class="rounded-circle">
                                                                </div>
                                                                <h6 class="fw-medium fs-14 mb-0">Brazil</h6>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            16459
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <div class="d-flex align-items-center gap-2">
                                                                <div>
                                                                    <img src="dashboard/assets/images/flags/au.svg" alt="" height="18" class="rounded-circle">
                                                                </div>
                                                                <h6 class="fw-medium fs-14 mb-0">Australia</h6>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            14795
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <div class="d-flex align-items-center gap-2">
                                                                <div>
                                                                    <img src="dashboard/assets/images/flags/ru.svg" alt="" height="18" class="rounded-circle">
                                                                </div>
                                                                <h6 class="fw-medium fs-14 mb-0">Russia</h6>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            13479
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <div class="d-flex align-items-center gap-2">
                                                                <div>
                                                                    <img src="dashboard/assets/images/flags/ca.svg" alt="" height="18" class="rounded-circle">
                                                                </div>
                                                                <h6 class="fw-medium fs-14 mb-0">Canada</h6>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            12645
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-xxl-12">
                                <div class="card">
                                    <div class="card-header align-items-center d-flex">
                                        <h4 class="card-title mb-0 flex-grow-1">Recent Orders</h4>
                                        <div class="flex-shrink-0">
                                            <div class="dropdown card-header-dropdown">
                                                <a class="text-reset dropdown-btn" href="#" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <span class="fw-semibold text-uppercase fs-12">Sort by:
                                                    </span><span class="text-muted">Today<i class="mdi mdi-chevron-down ms-1"></i></span>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-end">
                                                    <a class="dropdown-item" href="#">Today</a>
                                                    <a class="dropdown-item" href="#">Yesterday</a>
                                                    <a class="dropdown-item" href="#">Last 7 Days</a>
                                                    <a class="dropdown-item" href="#">Last 30 Days</a>
                                                    <a class="dropdown-item" href="#">This Month</a>
                                                    <a class="dropdown-item" href="#">Last Month</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div><!-- end card header -->
                        
                                    <div class="card-body">
                                        <div class="table-responsive table-card">
                                            <table class="table table-centered align-middle table-nowrap mb-0" id="customerTable">
                                                <thead class="text-muted table-light">
                                                    <tr>
                                                        <th scope="col" data-sort="orderId">Order ID</th>
                                                        <th scope="col" data-sort="product_name">Product Name</th>
                                                        <th scope="col">Customer Name</th>
                                                        <th scope="col">Amount</th>
                                                        <th scope="col">Order Date</th>
                                                        <th scope="col">Delivery Date</th>
                                                        <th scope="col">Vendor</th>
                                                        <th scope="col">Ratings</th>
                                                        <th scope="col">Status</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td>
                                                            <a href="orders-overview.html" class="fw-medium link-primary">#TB010331</a>
                                                        </td>
                                                        <td>
                                                            <a href="product-overview.html" class="text-reset">Macbook Pro</a>
                                                        </td>
                                                        <td>
                                                            <div class="d-flex align-items-center">
                                                                <div class="flex-shrink-0 me-2">
                                                                    <img src="dashboard/assets/images/users/avatar-2.jpg" alt="" class="avatar-xxs rounded-circle">
                                                                </div>
                                                                <div class="flex-grow-1">Terry White</div>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            $658.00
                                                        </td>
                                                        <td>17 Dec, 2022</td>
                                                        <td>26 Jan, 2023</td>
                                                        <td>Brazil</td>
                                                        <td>4.5 <i class="bi bi-star-half ms-1 text-warning fs-12"></i></td>
                                                        <td>
                                                            <span class="badge bg-info-subtle text-info ">New</span>
                                                        </td>
                                                    </tr><!-- end tr -->
                                                    <tr>
                                                        <td>
                                                            <a href="orders-overview.html" class="fw-medium link-primary">#TB010332</a>
                                                        </td>
                                                        <td>
                                                            <a href="product-overview.html" class="text-reset">Borosil Paper Cup</a>
                                                        </td>
                                                        <td>
                                                            <div class="d-flex align-items-center">
                                                                <div class="flex-shrink-0 me-2">
                                                                    <img src="dashboard/assets/images/users/avatar-4.jpg" alt="" class="avatar-xxs rounded-circle">
                                                                </div>
                                                                <div class="flex-grow-1">Daniel Gonzalez</div>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            $345.00
                                                        </td>
                                                        <td>02 Jan, 2023</td>
                                                        <td>26 Jan, 2023</td>
                                                        <td>Namibia</td>
                                                        <td>4.8<i class="bi bi-star-half ms-1 text-warning fs-12"></i></td>
                                                        <td>
                                                            <span class="badge bg-danger-subtle text-danger ">Out Of Delivery</span>
                                                        </td>
                                                    </tr><!-- end tr -->
                                                    <tr>
                                                        <td>
                                                            <a href="orders-overview.html" class="fw-medium link-primary">#TB010333</a>
                                                        </td>
                                                        <td>
                                                            <a href="product-overview.html" class="text-reset">Stillbird Helmet</a>
                                                        </td>
                                                        <td>
                                                            <div class="d-flex align-items-center">
                                                                <div class="flex-shrink-0 me-2">
                                                                    <img src="dashboard/assets/images/users/avatar-3.jpg" alt="" class="avatar-xxs rounded-circle">
                                                                </div>
                                                                <div class="flex-grow-1">Stephen Bird</div>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            $80.00
                                                        </td>
                                                        <td>20 Dec, 2022</td>
                                                        <td>29 Dec, 2022</td>
                                                        <td>USA</td>
                                                        <td>4.3 <i class="bi bi-star-half ms-1 text-warning fs-12"></i></td>
                                                        <td>
                                                            <span class="badge bg-success-subtle text-success ">Delivered</span>
                                                        </td>
                                                    </tr><!-- end tr -->
                                                    <tr>
                                                        <td>
                                                            <a href="orders-overview.html" class="fw-medium link-primary">#TB010334</a>
                                                        </td>
                                                        <td>
                                                            <a href="product-overview.html" class="text-reset">Bentwood Chair</a>
                                                        </td>
                                                        <td>
                                                            <div class="d-flex align-items-center">
                                                                <div class="flex-shrink-0 me-2">
                                                                    <img src="dashboard/assets/images/users/avatar-10.jpg" alt="" class="avatar-xxs rounded-circle">
                                                                </div>
                                                                <div class="flex-grow-1">Ashley Silva</div>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            $349.99
                                                        </td>
                                                        <td>31 Nov, 2022</td>
                                                        <td>13 Dec, 2022</td>
                                                        <td>Argentina</td>
                                                        <td>3.9 <i class="bi bi-star-half ms-1 text-warning fs-12"></i></td>
                                                        <td>
                                                            <span class="badge bg-warning-subtle text-warning ">Pending</span>
                                                        </td>
                                                    </tr><!-- end tr -->
                                                    <tr>
                                                        <td>
                                                            <a href="orders-overview.html" class="fw-medium link-primary">#TB010335</a>
                                                        </td>
                                                        <td>
                                                            <a href="product-overview.html" class="text-reset">Apple Headphone</a>
                                                        </td>
                                                        <td>
                                                            <div class="d-flex align-items-center">
                                                                <div class="flex-shrink-0 me-2">
                                                                    <img src="dashboard/assets/images/users/avatar-9.jpg" alt="" class="avatar-xxs rounded-circle">
                                                                </div>
                                                                <div class="flex-grow-1">Scott Wilson</div>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            $264.37
                                                        </td>
                                                        <td>23 Nov, 2022</td>
                                                        <td>03 Dec, 2022</td>
                                                        <td>Jersey</td>
                                                        <td>4.7 <i class="bi bi-star-half ms-1 text-warning fs-12"></i></td>
                                                        <td>
                                                            <span class="badge bg-primary-subtle text-primary ">Shipping</span>
                                                        </td>
                                                    </tr><!-- end tr -->
                                                    <tr>
                                                        <td>
                                                            <a href="orders-overview.html" class="fw-medium link-primary">#TB010336</a>
                                                        </td>
                                                        <td>
                                                            <a href="product-overview.html" class="text-reset">Smart Watch for Man's</a>
                                                        </td>
                                                        <td>
                                                            <div class="d-flex align-items-center">
                                                                <div class="flex-shrink-0 me-2">
                                                                    <img src="dashboard/assets/images/users/avatar-8.jpg" alt="" class="avatar-xxs rounded-circle">
                                                                </div>
                                                                <div class="flex-grow-1">Heather Jimenez</div>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            $741.98
                                                        </td>
                                                        <td>02 Nov, 2022</td>
                                                        <td>12 Nov, 2022</td>
                                                        <td>Spain</td>
                                                        <td>4.4 <i class="bi bi-star-half ms-1 text-warning fs-12"></i></td>
                                                        <td>
                                                            <span class="badge bg-success-subtle text-success ">Delivered</span>
                                                        </td>
                                                    </tr><!-- end tr -->
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="align-items-center mt-4 pt-2 justify-content-between d-flex">
                                            <div class="flex-shrink-0">
                                                <div class="text-muted">
                                                    Showing <span class="fw-semibold">6</span> of <span class="fw-semibold">25</span> Results
                                                </div>
                                            </div>
                                            <ul class="pagination pagination-separated pagination-sm mb-0">
                                                <li class="page-item disabled">
                                                    <a href="#" class="page-link">←</a>
                                                </li>
                                                <li class="page-item">
                                                    <a href="#" class="page-link">1</a>
                                                </li>
                                                <li class="page-item active">
                                                    <a href="#" class="page-link">2</a>
                                                </li>
                                                <li class="page-item">
                                                    <a href="#" class="page-link">3</a>
                                                </li>
                                                <li class="page-item">
                                                    <a href="#" class="page-link">→</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row widget-responsive-fullscreen">
                            <div class="col-xxl-3">
                                <div class="card card-height-100">
                                    <div class="card-header align-items-center d-flex">
                                        <h4 class="card-title mb-0 flex-grow-1">Customer Satisfaction</h4>
                                        <div class="flex-shrink-0">
                                            <div class="dropdown card-header-dropdown">
                                                <a class="text-reset dropdown-btn" href="#" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <span class="text-muted">Report<i class="mdi mdi-chevron-down ms-1"></i></span>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-end">
                                                    <a class="dropdown-item" href="#">Download Report</a>
                                                    <a class="dropdown-item" href="#">Export</a>
                                                    <a class="dropdown-item" href="#">Import</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div><!-- end card header -->
                            
                                    <div class="card-body">
                                        <div id="area_chart_spline" data-colors='["--tb-primary", "--tb-success"]' class="apex-charts" dir="ltr"></div>
                            
                                        <div class="mt-3 p-3 border rounded text-center">
                                            <div class="row">
                                                <div class="col-xl-6 border-end">
                                                    <h6 class="fs-17">$10,532</h6>
                                                    <p class="text-muted mb-0"><i class="bi bi-app-indicator text-primary align-middle me-1"></i> This Month</p>
                                                </div>
                                                <div class="col-xl-6">
                                                    <h6 class="fs-17">$9,532</h6>
                                                    <p class="text-muted mb-0"><i class="bi bi-app-indicator text-success align-middle me-1"></i> Last Month</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div> <!-- .card-->
                            </div> <!-- .col-->
                            <div class="col-xxl-9">
                                <div class="card">
                                    <div class="card-header align-items-center d-flex">
                                        <h4 class="card-title mb-0 flex-grow-1">Stock Report</h4>
                                        <div class="flex-shrink-0">
                                            <a href="statistics.html" class="btn btn-soft-info btn-sm">
                                                <i class="ri-file-list-3-line align-middle"></i> Generate Report
                                            </a>
                                        </div>
                                    </div><!-- end card header -->
                            
                                    <div class="card-body">
                                        <div class="table-responsive table-card">
                                            <table class="table table-borderless table-centered align-middle table-nowrap mb-0">
                                                <thead class="text-muted table-light">
                                                    <tr>
                                                        <th scope="col">Product ID</th>
                                                        <th scope="col">Product Name</th>
                                                        <th scope="col">Updated Date</th>
                                                        <th scope="col">Amount</th>
                                                        <th scope="col">Stock Status</th>
                                                        <th scope="col">Quantity</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td>
                                                            <a href="product-overview.html" class="fw-medium link-primary">#00541</a>
                                                        </td>
                                                        <td>
                                                            <div class="d-flex align-items-center">
                                                                <div class="flex-shrink-0 me-2">
                                                                    <img src="dashboard/assets/images/products/img-1.png" alt="" class="avatar-xs rounded-circle">
                                                                </div>
                                                                <div class="flex-grow-1"><a href="product-overview.html" class="text-reset">Rockerz Ear Bluetooth Headphones</a></div>
                                                            </div>
                                                        </td>
                                                        <td>16 Aug, 2022</td>
                                                        <td>
                                                            <span class="text-secondary">$658.00</span>
                                                        </td>
                                                        <td>
                                                            <span class="badge bg-success-subtle text-success ">In Stock</span>
                                                        </td>
                                                        <td>15 PCS</td>
                                                    </tr><!-- end tr -->
                                                    <tr>
                                                        <td>
                                                            <a href="product-overview.html" class="fw-medium link-primary">#07484</a>
                                                        </td>
                                                        <td>
                                                            <div class="d-flex align-items-center">
                                                                <div class="flex-shrink-0 me-2">
                                                                    <img src="dashboard/assets/images/products/img-5.png" alt="" class="avatar-xs rounded-circle">
                                                                </div>
                                                                <div class="flex-grow-1"><a href="product-overview.html" class="text-reset">United Colors Of Benetton</a></div>
                                                            </div>
                                                        </td>
                                                        <td>05 Sep, 2022</td>
                                                        <td>
                                                            <span class="text-secondary">$145.00</span>
                                                        </td>
                                                        <td>
                                                            <span class="badge bg-warning-subtle text-warning ">Low Stock</span>
                                                        </td>
                                                        <td>05 PCS</td>
                                                    </tr><!-- end tr -->
                                                    <tr>
                                                        <td>
                                                            <a href="product-overview.html" class="fw-medium link-primary">#01641</a>
                                                        </td>
                                                        <td>
                                                            <div class="d-flex align-items-center">
                                                                <div class="flex-shrink-0 me-2">
                                                                    <img src="dashboard/assets/images/products/img-4.png" alt="" class="avatar-xs rounded-circle">
                                                                </div>
                                                                <div class="flex-grow-1"><a href="product-overview.html" class="text-reset">Striped Baseball Cap</a></div>
                                                            </div>
                                                        </td>
                                                        <td>28 Sep, 2022</td>
                                                        <td>
                                                            <span class="text-secondary">$215.00</span>
                                                        </td>
                                                        <td>
                                                            <span class="badge bg-danger-subtle text-danger ">Out of Stock</span>
                                                        </td>
                                                        <td>0 PCS</td>
                                                    </tr><!-- end tr -->
                                                    <tr>
                                                        <td>
                                                            <a href="product-overview.html" class="fw-medium link-primary">#00065</a>
                                                        </td>
                                                        <td>
                                                            <div class="d-flex align-items-center">
                                                                <div class="flex-shrink-0 me-2">
                                                                    <img src="dashboard/assets/images/products/img-3.png" alt="" class="avatar-xs rounded-circle">
                                                                </div>
                                                                <div class="flex-grow-1"><a href="product-overview.html" class="text-reset">350 ml Glass Grocery Container</a></div>
                                                            </div>
                                                        </td>
                                                        <td>02 Oct, 2022</td>
                                                        <td>
                                                            <span class="text-secondary">$79.99</span>
                                                        </td>
                                                        <td>
                                                            <span class="badge bg-success-subtle text-success ">In Stock</span>
                                                        </td>
                                                        <td>37 PCS</td>
                                                    </tr><!-- end tr -->
                                                    <tr>
                                                        <td>
                                                            <a href="product-overview.html" class="fw-medium link-primary">#00156</a>
                                                        </td>
                                                        <td>
                                                            <div class="d-flex align-items-center">
                                                                <div class="flex-shrink-0 me-2">
                                                                    <img src="dashboard/assets/images/products/img-2.png" alt="" class="avatar-xs rounded-circle">
                                                                </div>
                                                                <div class="flex-grow-1"><a href="product-overview.html" class="text-reset">One Seater Sofa</a></div>
                                                            </div>
                                                        </td>
                                                        <td>11 Oct, 2022</td>
                                                        <td>
                                                            <span class="text-secondary">$264.99</span>
                                                        </td>
                                                        <td>
                                                            <span class="badge bg-success-subtle text-success ">In Stock</span>
                                                        </td>
                                                        <td>23 PCS</td>
                                                    </tr><!-- end tr -->
                                                    <tr>
                                                        <td>
                                                            <a href="product-overview.html" class="fw-medium link-primary">#09102</a>
                                                        </td>
                                                        <td>
                                                            <div class="d-flex align-items-center">
                                                                <div class="flex-shrink-0 me-2">
                                                                    <img src="dashboard/assets/images/products/img-8.png" alt="" class="avatar-xs rounded-circle">
                                                                </div>
                                                                <div class="flex-grow-1"><a href="product-overview.html" class="text-reset">Men's Running Shoes Active Grip</a></div>
                                                            </div>
                                                        </td>
                                                        <td>19 Nov, 2022</td>
                                                        <td>
                                                            <span class="text-secondary">$264.99</span>
                                                        </td>
                                                        <td>
                                                            <span class="badge bg-warning-subtle text-warning ">Low Stock</span>
                                                        </td>
                                                        <td>23 PCS</td>
                                                    </tr><!-- end tr -->
                                                </tbody><!-- end tbody -->
                                            </table><!-- end table -->
                                        </div>
                                    </div>
                                </div> <!-- .card-->
                            </div> <!-- .col-->
                            <div class="col-xxl-3 col-lg-6">
                                <div class="card">
                                    <div class="card-header d-flex">
                                        <h5 class="card-title flex-grow-1 mb-0">Product Delivery</h5>
                                        <a href="#" class="flex-shrink-0">View All <i class="ri-arrow-right-line align-bottom ms-1"></i></a>
                                    </div>
                                    <div class="card-body px-0">
                                        <div data-simplebar style="max-height: 415px;">
                                            <div class="vstack gap-3 px-3">
                                                <div class="p-3 border border-dashed rounded-3">
                                                    <div class="d-flex align-items-center gap-2">
                                                        <div class="avatar-sm bg-light rounded p-1 flex-shrink-0">
                                                            <img src="dashboard/assets/images/products/img-8.png" alt="" class="img-fluid d-block">
                                                        </div>
                                                        <div class="flex-grow-1">
                                                            <a href="product-overview.html">
                                                                <h6>Men's Running Shoes Activ... </h6>
                                                            </a>
                                                            <p class="mb-0">by: <span class="text-info">Aisha Bradley</span></p>
                                                        </div>
                                                        <div class="flex-shrink-0">
                                                            <span class="badge bg-warning-subtle text-warning ">Shipping</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="p-3 border border-dashed rounded-3">
                                                    <div class="d-flex align-items-center gap-2">
                                                        <div class="avatar-sm bg-light rounded p-1 flex-shrink-0">
                                                            <img src="dashboard/assets/images/products/img-4.png" alt="" class="img-fluid d-block">
                                                        </div>
                                                        <div class="flex-grow-1">
                                                            <a href="product-overview.html">
                                                                <h6>Striped Baseball Cap</h6>
                                                            </a>
                                                            <p class="mb-0">by: <span class="text-info">Edgar Bailey</span></p>
                                                        </div>
                                                        <div class="flex-shrink-0">
                                                            <span class="badge bg-success-subtle text-success ">Delivered</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="p-3 border border-dashed rounded-3">
                                                    <div class="d-flex align-items-center gap-2">
                                                        <div class="avatar-sm bg-light rounded p-1 flex-shrink-0">
                                                            <img src="dashboard/assets/images/products/img-3.png" alt="" class="img-fluid d-block">
                                                        </div>
                                                        <div class="flex-grow-1">
                                                            <a href="product-overview.html">
                                                                <h6>350 ml Glass Groce...</h6>
                                                            </a>
                                                            <p class="mb-0">by: <span class="text-info">Adam Small</span></p>
                                                        </div>
                                                        <div class="flex-shrink-0">
                                                            <span class="badge bg-danger-subtle text-danger ">Out of Delivery</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="p-3 border border-dashed rounded-3">
                                                    <div class="d-flex align-items-center gap-2">
                                                        <div class="avatar-sm bg-light rounded p-1 flex-shrink-0">
                                                            <img src="dashboard/assets/images/products/img-6.png" alt="" class="img-fluid d-block">
                                                        </div>
                                                        <div class="flex-grow-1">
                                                            <a href="product-overview.html">
                                                                <h6>Monte Carlo Sweaters</h6>
                                                            </a>
                                                            <p class="mb-0">by: <span class="text-info">Evie Merrill</span></p>
                                                        </div>
                                                        <div class="flex-shrink-0">
                                                            <span class="badge bg-success-subtle text-success ">Delivered</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="p-3 border border-dashed rounded-3">
                                                    <div class="d-flex align-items-center gap-2">
                                                        <div class="avatar-sm bg-light rounded p-1 flex-shrink-0">
                                                            <img src="dashboard/assets/images/products/img-9.png" alt="" class="img-fluid d-block">
                                                        </div>
                                                        <div class="flex-grow-1">
                                                            <a href="product-overview.html">
                                                                <h6>Ceramic Coffee Mug</h6>
                                                            </a>
                                                            <p class="mb-0">by: <span class="text-info">Keaton Larson</span></p>
                                                        </div>
                                                        <div class="flex-shrink-0">
                                                            <span class="badge bg-warning-subtle text-warning ">Shipping</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xxl-3 col-lg-6">
                                <div class="card card-height-100">
                                    <div class="card-header align-items-center d-flex">
                                        <h4 class="card-title mb-0 flex-grow-1">Top Categories</h4>
                                        <div class="flex-shrink-0">
                                            <div class="dropdown card-header-dropdown">
                                                <a class="text-reset dropdown-btn" href="#" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <span class="text-muted">Report<i class="mdi mdi-chevron-down ms-1"></i></span>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-end">
                                                    <a class="dropdown-item" href="#">Download Report</a>
                                                    <a class="dropdown-item" href="#">Export</a>
                                                    <a class="dropdown-item" href="#">Import</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div><!-- end card header -->
                            
                                    <div class="card-body">
                                        <div id="multiple_radialbar" data-colors='["--tb-primary", "--tb-danger", "--tb-success", "--tb-secondary"]' class="apex-charts" dir="ltr"></div>
                            
                                        <div class="row g-3">
                                            <div class="col-md-6">
                                                <div class="card text-center border-dashed mb-0">
                                                    <div class="card-body">
                                                        <h6 class="fs-16">986</h6>
                                                        <i class="bi bi-square-fill text-primary me-1 fs-11"></i> Fashion
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="card text-center border-dashed mb-0">
                                                    <div class="card-body">
                                                        <h6 class="fs-16">874</h6>
                                                        <i class="bi bi-square-fill text-danger me-1 fs-11"></i> Electronics
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="card text-center border-dashed mb-0">
                                                    <div class="card-body">
                                                        <h6 class="fs-16">321</h6>
                                                        <i class="bi bi-square-fill text-success me-1 fs-11"></i> Groceries
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="card text-center border-dashed mb-0">
                                                    <div class="card-body">
                                                        <h6 class="fs-16">741</h6>
                                                        <i class="bi bi-square-fill text-secondary me-1 fs-11"></i> Others
                                                    </div>
                                                </div>
                                            </div><!--end col-->
                                        </div><!--end row-->
                                    </div>
                                </div> <!-- .card-->
                            </div> <!-- .col-->
                            <div class="col-xxl-3 col-lg-6">
                                <div class="card card-height-100">
                                    <div class="card-header align-items-center d-flex">
                                        <h4 class="card-title mb-0 flex-grow-1">New Customers</h4>
                                        <a href="users-list.html" class="flex-shrink-0">View All <i class="ri-arrow-right-line align-bottom ms-1"></i></a>
                                    </div><!-- end card header -->
                            
                                    <div data-simplebar style="max-height: 445px;">
                                        <div class="p-3 border-bottom border-bottom-dashed">
                                            <div class="d-flex align-items-center gap-2">
                                                <div class="flex-shrink-0">
                                                    <img src="dashboard/assets/images/users/avatar-2.jpg" alt="" class="rounded dash-avatar">
                                                </div>
                                                <div class="flex-grow-1">
                                                    <h6 class="mb-1">Tommy Carey</h6>
                                                    <p class="fs-13 text-muted mb-0">02 Jan, 2023</p>
                                                </div>
                                                <div class="flex-shrink-0">
                                                    <a href="mailto:careytommy@toner.com" class="btn btn-icon btn-sm btn-soft-danger"><i class="ph-envelope"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="p-3 border-bottom border-bottom-dashed">
                                            <div class="d-flex align-items-center gap-2">
                                                <div class="flex-shrink-0">
                                                    <img src="dashboard/assets/images/users/avatar-1.jpg" alt="" class="rounded dash-avatar">
                                                </div>
                                                <div class="flex-grow-1">
                                                    <h6 class="mb-1">Cassius Brock</h6>
                                                    <p class="fs-13 text-muted mb-0">24 Nov, 2022</p>
                                                </div>
                                                <div class="flex-shrink-0">
                                                    <a href="mailto:brock@toner.com" class="btn btn-icon btn-sm btn-soft-danger"><i class="ph-envelope"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="p-3 border-bottom border-bottom-dashed">
                                            <div class="d-flex align-items-center gap-2">
                                                <div class="flex-shrink-0">
                                                    <img src="dashboard/assets/images/users/avatar-3.jpg" alt="" class="rounded dash-avatar">
                                                </div>
                                                <div class="flex-grow-1">
                                                    <h6 class="mb-1">Gabrielle Holden</h6>
                                                    <p class="fs-13 text-muted mb-0">17 Nav, 2022</p>
                                                </div>
                                                <div class="flex-shrink-0">
                                                    <a href="mailto:gabrielle@toner.com" class="btn btn-icon btn-sm btn-soft-danger"><i class="ph-envelope"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="p-3 border-bottom border-bottom-dashed">
                                            <div class="d-flex align-items-center gap-2">
                                                <div class="flex-shrink-0">
                                                    <img src="dashboard/assets/images/users/avatar-5.jpg" alt="" class="rounded dash-avatar">
                                                </div>
                                                <div class="flex-grow-1">
                                                    <h6 class="mb-1">Alfred Hurst</h6>
                                                    <p class="fs-13 text-muted mb-0">18 Dec, 2021</p>
                                                </div>
                                                <div class="flex-shrink-0">
                                                    <a href="mailto:" class="btn btn-icon btn-sm btn-soft-danger"><i class="ph-envelope"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="p-3 border-bottom border-bottom-dashed">
                                            <div class="d-flex align-items-center gap-2">
                                                <div class="flex-shrink-0">
                                                    <img src="dashboard/assets/images/users/avatar-6.jpg" alt="" class="rounded dash-avatar">
                                                </div>
                                                <div class="flex-grow-1">
                                                    <h6 class="mb-1">Kristina Hooper</h6>
                                                    <p class="fs-13 text-muted mb-0">04 Oct, 2022</p>
                                                </div>
                                                <div class="flex-shrink-0">
                                                    <a href="mailto:alfredH@toner.com" class="btn btn-icon btn-sm btn-soft-danger"><i class="ph-envelope"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="p-3 border-bottom border-bottom-dashed">
                                            <div class="d-flex align-items-center gap-2">
                                                <div class="flex-shrink-0">
                                                    <img src="dashboard/assets/images/users/avatar-8.jpg" alt="" class="rounded dash-avatar">
                                                </div>
                                                <div class="flex-grow-1">
                                                    <h6 class="mb-1">Jacques Leon</h6>
                                                    <p class="fs-13 text-muted mb-0">02 Jan, 2023</p>
                                                </div>
                                                <div class="flex-shrink-0">
                                                    <a href="mailto:jacques@toner.com" class="btn btn-icon btn-sm btn-soft-danger"><i class="ph-envelope"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="p-3 border-bottom border-bottom-dashed">
                                            <div class="d-flex align-items-center gap-2">
                                                <div class="flex-shrink-0">
                                                    <img src="dashboard/assets/images/users/avatar-7.jpg" alt="" class="rounded dash-avatar">
                                                </div>
                                                <div class="flex-grow-1">
                                                    <h6 class="mb-1">Edward Rogers</h6>
                                                    <p class="fs-13 mb-0">25 Nov, 2022</p>
                                                </div>
                                                <div class="flex-shrink-0">
                                                    <a href="mailto:edwardro@toner.com" class="btn btn-icon btn-sm btn-soft-danger"><i class="ph-envelope"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="p-3 border-bottom border-bottom-dashed">
                                            <div class="d-flex align-items-center gap-2">
                                                <div class="flex-shrink-0">
                                                    <img src="dashboard/assets/images/users/avatar-10.jpg" alt="" class="rounded dash-avatar">
                                                </div>
                                                <div class="flex-grow-1">
                                                    <h6 class="mb-1">Alina Holland</h6>
                                                    <p class="fs-13 mb-0">11 Jan, 2023</p>
                                                </div>
                                                <div class="flex-shrink-0">
                                                    <a href="mailto:hollandalina@toner.com" class="btn btn-icon btn-sm btn-soft-danger"><i class="ph-envelope"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div> <!-- .card-->
                            </div> <!-- .col-->
                            <div class="col-xxl-3 col-lg-6">
                                <div class="card card-height-100">
                                    <div class="card-header align-items-center d-flex">
                                        <h4 class="card-title mb-0 flex-grow-1">Top Products</h4>
                                        <div class="flex-shrink-0">
                                            <div class="dropdown card-header-dropdown">
                                                <a class="text-reset dropdown-btn" href="#" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <span class="text-muted">Report<i class="mdi mdi-chevron-down ms-1"></i></span>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-end">
                                                    <a class="dropdown-item" href="#">Download Report</a>
                                                    <a class="dropdown-item" href="#">Export</a>
                                                    <a class="dropdown-item" href="#">Import</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div><!-- end card header -->
                            
                                    <div class="card-body">
                                        <div class="mb-4">
                                            <span class="badge bg-dark-subtle text-body  float-end">90%</span>
                                            <h6 class="mb-2">Fashion & Clothing</h6>
                                            <div class="progress progress-sm" role="progressbar" aria-label="Success example" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100">
                                                <div class="progress-bar bg-success bg-opacity-50 progress-bar-striped progress-bar-animated" style="width: 90%"></div>
                                            </div>
                                        </div>
                                        <div class="mb-4">
                                            <span class="badge bg-dark-subtle text-body  float-end">64%</span>
                                            <h6 class="mb-2">Lighting</h6>
                                            <div class="progress progress-sm" role="progressbar" aria-label="Success example" aria-valuenow="64" aria-valuemin="0" aria-valuemax="100">
                                                <div class="progress-bar bg-warning bg-opacity-50 progress-bar-striped progress-bar-animated" style="width: 64%"></div>
                                            </div>
                                        </div>
                                        <div class="mb-4">
                                            <span class="badge bg-dark-subtle text-body  float-end">77%</span>
                                            <h6 class="mb-2">Footwear</h6>
                                            <div class="progress progress-sm" role="progressbar" aria-label="Success example" aria-valuenow="77" aria-valuemin="0" aria-valuemax="100">
                                                <div class="progress-bar bg-danger bg-opacity-50 progress-bar-striped progress-bar-animated" style="width: 77%"></div>
                                            </div>
                                        </div>
                                        <div class="mb-4">
                                            <span class="badge bg-dark-subtle text-body  float-end">53%</span>
                                            <h6 class="mb-2">Electronics</h6>
                                            <div class="progress progress-sm" role="progressbar" aria-label="Success example" aria-valuenow="53" aria-valuemin="0" aria-valuemax="100">
                                                <div class="progress-bar bg-info bg-opacity-50 progress-bar-striped progress-bar-animated" style="width: 53%"></div>
                                            </div>
                                        </div>
                                        <div class="mb-4">
                                            <span class="badge bg-dark-subtle text-body  float-end">81%</span>
                                            <h6 class="mb-2">Beauty & Personal Care</h6>
                                            <div class="progress progress-sm" role="progressbar" aria-label="Success example" aria-valuenow="81" aria-valuemin="0" aria-valuemax="100">
                                                <div class="progress-bar bg-primary bg-opacity-50 progress-bar-striped progress-bar-animated" style="width: 81%"></div>
                                            </div>
                                        </div>
                                        <div class="mb-4">
                                            <span class="badge bg-dark-subtle text-body  float-end">96%</span>
                                            <h6 class="mb-2">Books</h6>
                                            <div class="progress progress-sm" role="progressbar" aria-label="Success example" aria-valuenow="96" aria-valuemin="0" aria-valuemax="100">
                                                <div class="progress-bar bg-secondary bg-opacity-50 progress-bar-striped progress-bar-animated" style="width: 96%"></div>
                                            </div>
                                        </div>
                                        <div class="mb-4">
                                            <span class="badge bg-dark-subtle text-body  float-end">69%</span>
                                            <h6 class="mb-2">Furniture</h6>
                                            <div class="progress progress-sm" role="progressbar" aria-label="Success example" aria-valuenow="69" aria-valuemin="0" aria-valuemax="100">
                                                <div class="progress-bar bg-success bg-opacity-50 progress-bar-striped progress-bar-animated" style="width: 69%"></div>
                                            </div>
                                        </div>
                                        <div>
                                            <span class="badge bg-dark-subtle text-body  float-end">63%</span>
                                            <h6 class="mb-2">Mobile Accessories</h6>
                                            <div class="progress progress-sm" role="progressbar" aria-label="Success example" aria-valuenow="63" aria-valuemin="0" aria-valuemax="100">
                                                <div class="progress-bar bg-dark bg-opacity-50 progress-bar-striped progress-bar-animated" style="width: 63%"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div> <!-- .card-->
                            </div> <!-- .col-->
                        </div> <!-- end row-->
                        
                    </div>
                    <!-- container-fluid -->
                </div>
                <!-- End Page-content -->

                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-sm-6">
                                <script>document.write(new Date().getFullYear())</script> © Toner.
                            </div>
                            <div class="col-sm-6">
                                <div class="text-sm-end d-none d-sm-block">
                                    Design & Develop by Themesbrand
                                </div>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
            <!-- end main content-->

        </div>  
        <!-- END layout-wrapper -->


        <!--start back-to-top-->
        <button onclick="topFunction()" class="btn btn-info btn-icon" id="back-to-top">
            <i class="ri-arrow-up-line"></i>
        </button>
        <!--end back-to-top-->

        <a class="btn btn-danger shadow-lg chat-button rounded-bottom-0 d-none d-lg-block" data-bs-toggle="collapse" href="#chatBot" role="button" aria-expanded="false" aria-controls="chatBot">Online Chat</a>
        <div class="collapse chat-box" id="chatBot">
            <div class="card shadow-lg border-0 rounded-bottom-0 mb-0">
                <div class="card-header bg-success d-flex align-items-center border-0">
                    <h5 class="text-white fs-16 fw-medium flex-grow-1 mb-0">Hi, Raquel Murillo 👋</h5>
                    <button type="button" class="btn-close btn-close-white flex-shrink-0" onclick="chatBot()" data-bs-dismiss="collapse" aria-label="Close"></button>
                </div>
                <div class="card-body p-0">
                    <div id="users-chat-widget">
                        <div class="chat-conversation p-3" id="chat-conversation" data-simplebar style="height: 280px;">
                            <ul class="list-unstyled chat-conversation-list chat-sm" id="users-conversation">
                                <li class="chat-list left">
                                    <div class="conversation-list">
                                        <div class="chat-avatar">
                                            <img src="dashboard/assets/images/logo-sm.png" alt="">
                                        </div>
                                        <div class="user-chat-content">
                                            <div class="ctext-wrap">
                                                <div class="ctext-wrap-content">
                                                    <p class="mb-0 ctext-content">Welcome to Themesbrand. We are here to help you. You can also directly email us at Support@themesbrand.com to schedule a meeting with our Technology Consultant.</p>
                                                </div>
                                                <div class="dropdown align-self-start message-box-drop">
                                                    <a class="dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        <i class="ri-more-2-fill"></i>
                                                    </a>
                                                    <div class="dropdown-menu">
                                                        <a class="dropdown-item" href="#"><i class="ri-reply-line me-2 text-muted align-bottom"></i>Reply</a>
                                                        <a class="dropdown-item" href="#"><i class="ri-file-copy-line me-2 text-muted align-bottom"></i>Copy</a>
                                                        <a class="dropdown-item delete-item" href="#"><i class="ri-delete-bin-5-line me-2 text-muted align-bottom"></i>Delete</a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="conversation-name"><small class="text-muted time">09:07 am</small> <span class="text-success check-message-icon"><i class="ri-check-double-line align-bottom"></i></span></div>
                                        </div>
                                    </div>
                                </li>
                                <!-- chat-list -->
            
                                <li class="chat-list right">
                                    <div class="conversation-list">
                                        <div class="user-chat-content">
                                            <div class="ctext-wrap">
                                                <div class="ctext-wrap-content">
                                                    <p class="mb-0 ctext-content">Good morning, How are you? What about our next meeting?</p>
                                                </div>
                                                <div class="dropdown align-self-start message-box-drop">
                                                    <a class="dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        <i class="ri-more-2-fill"></i>
                                                    </a>
                                                    <div class="dropdown-menu">
                                                        <a class="dropdown-item" href="#"><i class="ri-reply-line me-2 text-muted align-bottom"></i>Reply</a>
                                                        <a class="dropdown-item" href="#"><i class="ri-file-copy-line me-2 text-muted align-bottom"></i>Copy</a>
                                                        <a class="dropdown-item delete-item" href="#"><i class="ri-delete-bin-5-line me-2 text-muted align-bottom"></i>Delete</a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="conversation-name"><small class="text-muted time">09:08 am</small> <span class="text-success check-message-icon"><i class="ri-check-double-line align-bottom"></i></span></div>
                                        </div>
                                    </div>
                                </li>
                                <!-- chat-list -->
            
                                <li class="chat-list left">
                                    <div class="conversation-list">
                                        <div class="chat-avatar">
                                            <img src="dashboard/assets/images/logo-sm.png" alt="">
                                        </div>
                                        <div class="user-chat-content">
                                            <div class="ctext-wrap">
                                                <div class="ctext-wrap-content">
                                                    <p class="mb-0 ctext-content">Yeah everything is fine. Our next meeting tomorrow at 10.00 AM</p>
                                                </div>
                                                <div class="dropdown align-self-start message-box-drop">
                                                    <a class="dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        <i class="ri-more-2-fill"></i>
                                                    </a>
                                                    <div class="dropdown-menu">
                                                        <a class="dropdown-item" href="#"><i class="ri-reply-line me-2 text-muted align-bottom"></i>Reply</a>
                                                        <a class="dropdown-item" href="#"><i class="ri-file-copy-line me-2 text-muted align-bottom"></i>Copy</a>
                                                        <a class="dropdown-item delete-item" href="#"><i class="ri-delete-bin-5-line me-2 text-muted align-bottom"></i>Delete</a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="conversation-name"><small class="text-muted time">09:10 am</small> <span class="text-success check-message-icon"><i class="ri-check-double-line align-bottom"></i></span></div>
                                        </div>
                                    </div>
                                </li>
                                <!-- chat-list -->
            
                            </ul>
                        </div>
                    </div>
                    <div class="border-top border-top-dashed">
                        <div class="row g-2 mt-2 mx-3 mb-3">
                            <div class="col">
                                <div class="position-relative">
                                    <input type="text" class="form-control border-light bg-light" placeholder="Enter Message...">
                                </div>
                            </div><!-- end col -->
                            <div class="col-auto">
                                <button type="submit" class="btn btn-info"><i class="mdi mdi-send"></i></button>
                            </div><!-- end col -->
                        </div><!-- end row -->
                    </div>
                </div>
            </div>
        </div>

        <!--preloader-->
        <div id="preloader">
            <div id="status">
                <div class="spinner-border text-primary avatar-sm" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
            </div>
        </div>

        <div class="customizer-setting d-none d-md-block">
            <div class="btn-secondary btn-rounded shadow-lg btn btn-icon btn-lg p-2" data-bs-toggle="offcanvas" data-bs-target="#theme-settings-offcanvas" aria-controls="theme-settings-offcanvas">
                <i class='mdi mdi-spin mdi-cog-outline fs-22'></i>
            </div>
        </div>

        <!-- Theme Settings -->
        <div class="offcanvas offcanvas-end border-0" tabindex="-1" id="theme-settings-offcanvas">
            <div class="d-flex align-items-center bg-primary p-3 offcanvas-header">
                <h5 class="m-0 me-2 text-white">Theme Customizer</h5>

                <button type="button" class="btn-close btn-close-white ms-auto" id="customizerclose-btn" data-bs-dismiss="offcanvas" aria-label="Close"></button>
            </div>
            <div class="offcanvas-body p-0">
                <div data-simplebar class="h-100">
                    <div class="p-4">

                        <!-- <h6 class="mb-1 fs-15 fw-semibold text-uppercase">View Website</h6>
                        <p class="text-muted">Choose your</p> -->

                        <div class="mb-4 hstack gap-2">
                            <a href="dashboard/frontend/index.html" target="_blank" class="btn btn-secondary">Visit Your Website</a>
                            <a href="dashboard/components/index.html" target="_blank" class="btn btn-success">Components</a>
                        </div>

                        <h6 class="mb-1 fs-15 fw-semibold text-uppercase">Layout</h6>
                        <p class="text-muted">Choose your layout</p>

                        <div class="row gy-3">
                            <div class="col-6">
                                <div class="form-check card-radio customize-widget">
                                    <input id="customizer-layout01" name="data-layout" type="radio" value="vertical" class="form-check-input">
                                    <label class="form-check-label p-0 avatar-xl w-100" for="customizer-layout01">
                                        <span class="customize-penal-main w-100 d-block d-flex align-items-center">
                                            <span class="d-flex align-items-center gap-1 ps-1">
                                                <span class="d-inline-block badge p-0 text-bg-danger rounded-circle"></span>
                                                <span class="d-inline-block badge p-0 text-bg-success rounded-circle"></span>
                                                <span class="d-inline-block badge p-0 text-bg-warning rounded-circle"></span>
                                            </span>
                                        </span>
                                        <span class="d-flex gap-1 h-100">
                                            <span class="flex-shrink-0">
                                                <span class="bg-light d-flex h-100 flex-column gap-1 p-2">
                                                    <span class="d-block p-1 px-2 bg-primary-subtle rounded mb-2"></span>
                                                    <span class="d-block p-1 px-2 pb-0 bg-primary-subtle"></span>
                                                    <span class="d-block p-1 px-2 pb-0 bg-primary-subtle"></span>
                                                    <span class="d-block p-1 px-2 pb-0 bg-primary-subtle"></span>
                                                </span>
                                            </span>
                                            <span class="flex-grow-1">
                                                <span class="d-flex h-100 flex-column">
                                                    <span class="bg-light d-block p-2"></span>
                                                    <span class="bg-light d-block p-2 mt-auto"></span>
                                                </span>
                                            </span>
                                        </span>
                                    </label>
                                </div>
                                <h5 class="fs-14 text-center mt-2">Vertical</h5>
                            </div>
                            <div class="col-6">
                                <div class="form-check card-radio customize-widget">
                                    <input id="customizer-layout02" name="data-layout" type="radio" value="horizontal" class="form-check-input">
                                    <label class="form-check-label p-0 avatar-xl w-100" for="customizer-layout02">
                                        <span class="customize-penal-main w-100 d-block d-flex align-items-center">
                                            <span class="d-flex align-items-center gap-1 ps-1">
                                                <span class="d-inline-block badge p-0 text-bg-danger rounded-circle"></span>
                                                <span class="d-inline-block badge p-0 text-bg-success rounded-circle"></span>
                                                <span class="d-inline-block badge p-0 text-bg-warning rounded-circle"></span>
                                            </span>
                                        </span>
                                        <span class="d-flex h-100 flex-column gap-1">
                                            <span class="bg-light d-flex p-1 gap-1 align-items-center">
                                                <span class="d-block p-1 bg-primary-subtle rounded me-1"></span>
                                                <span class="d-block p-1 pb-0 px-2 bg-primary-subtle ms-auto"></span>
                                                <span class="d-block p-1 pb-0 px-2 bg-primary-subtle"></span>
                                            </span>
                                            <span class="bg-light d-block p-1"></span>
                                            <span class="bg-light d-block p-1 mt-auto"></span>
                                        </span>
                                    </label>
                                </div>
                                <h5 class="fs-14 text-center mt-2">Horizontal</h5>
                            </div>
                            <div class="col-6">
                                <div class="form-check card-radio customize-widget">
                                    <input id="customizer-layout03" name="data-layout" type="radio" value="twocolumn" class="form-check-input">
                                    <label class="form-check-label p-0 avatar-xl w-100" for="customizer-layout03">
                                        <span class="customize-penal-main w-100 d-block d-flex align-items-center">
                                            <span class="d-flex align-items-center gap-1 ps-1">
                                                <span class="d-inline-block badge p-0 text-bg-danger rounded-circle"></span>
                                                <span class="d-inline-block badge p-0 text-bg-success rounded-circle"></span>
                                                <span class="d-inline-block badge p-0 text-bg-warning rounded-circle"></span>
                                            </span>
                                        </span>
                                        <span class="d-flex gap-1 h-100">
                                            <span class="flex-shrink-0">
                                                <span class="bg-light d-flex h-100 flex-column gap-1 p-1">
                                                    <span class="d-block p-1 bg-primary-subtle mb-2"></span>
                                                    <span class="d-block p-1 pb-0 bg-primary-subtle"></span>
                                                    <span class="d-block p-1 pb-0 bg-primary-subtle"></span>
                                                    <span class="d-block p-1 pb-0 bg-primary-subtle"></span>
                                                </span>
                                            </span>
                                            <span class="flex-shrink-0">
                                                <span class="bg-light d-flex h-100 flex-column gap-1 p-2">
                                                    <span class="d-block p-1 px-2 pb-0 bg-primary-subtle"></span>
                                                    <span class="d-block p-1 px-2 pb-0 bg-primary-subtle"></span>
                                                    <span class="d-block p-1 px-2 pb-0 bg-primary-subtle"></span>
                                                    <span class="d-block p-1 px-2 pb-0 bg-primary-subtle"></span>
                                                </span>
                                            </span>
                                            <span class="flex-grow-1">
                                                <span class="d-flex h-100 flex-column">
                                                    <span class="bg-light d-block p-2"></span>
                                                    <span class="bg-light d-block p-1 mt-auto"></span>
                                                </span>
                                            </span>
                                        </span>
                                    </label>
                                </div>
                                <h5 class="fs-14 text-center mt-2">Two Column</h5>
                            </div>
                            <!-- end col -->
                        </div>

                        <h6 class="mt-4 mb-1 fs-15 fw-semibold text-uppercase">Color Scheme</h6>
                        <p class="text-muted">Choose Light or Dark Scheme.</p>

                        <div class="colorscheme-cardradio">
                            <div class="row gy-3">
                                <div class="col-6">
                                    <div class="form-check card-radio customize-widget">
                                        <input class="form-check-input" type="radio" name="data-bs-theme" id="layout-mode-light" value="light">
                                        <label class="form-check-label p-0 avatar-xl w-100" for="layout-mode-light">
                                            <span class="customize-penal-main w-100 d-block d-flex align-items-center">
                                                <span class="d-flex align-items-center gap-1 ps-1">
                                                    <span class="d-inline-block badge p-0 text-bg-danger rounded-circle"></span>
                                                    <span class="d-inline-block badge p-0 text-bg-success rounded-circle"></span>
                                                    <span class="d-inline-block badge p-0 text-bg-warning rounded-circle"></span>
                                                </span>
                                            </span>
                                            <span class="d-flex gap-1 h-100">
                                                <span class="flex-shrink-0">
                                                    <span class="bg-light d-flex h-100 flex-column gap-1 p-1">
                                                        <span class="d-block p-1 px-2 bg-primary-subtle rounded mb-2"></span>
                                                        <span class="d-block p-1 px-2 pb-0 bg-primary-subtle"></span>
                                                        <span class="d-block p-1 px-2 pb-0 bg-primary-subtle"></span>
                                                        <span class="d-block p-1 px-2 pb-0 bg-primary-subtle"></span>
                                                    </span>
                                                </span>
                                                <span class="flex-grow-1">
                                                    <span class="d-flex h-100 flex-column">
                                                        <span class="bg-light d-block p-1"></span>
                                                        <span class="bg-light d-block p-1 mt-auto"></span>
                                                    </span>
                                                </span>
                                            </span>
                                        </label>
                                    </div>
                                    <h5 class="fs-14 text-center mt-2">Light</h5>
                                </div>

                                <div class="col-6">
                                    <div class="form-check card-radio dark customize-widget">
                                        <input class="form-check-input" type="radio" name="data-bs-theme" id="layout-mode-dark" value="dark">
                                        <label class="form-check-label p-0 avatar-xl w-100 bg-dark" for="layout-mode-dark">
                                            <span class="customize-penal-main w-100 d-block d-flex align-items-center">
                                                <span class="d-flex align-items-center gap-1 ps-1">
                                                    <span class="d-inline-block badge p-0 text-bg-danger rounded-circle"></span>
                                                    <span class="d-inline-block badge p-0 text-bg-success rounded-circle"></span>
                                                    <span class="d-inline-block badge p-0 text-bg-warning rounded-circle"></span>
                                                </span>
                                            </span>
                                            <span class="d-flex gap-1 h-100">
                                                <span class="flex-shrink-0">
                                                    <span class="bg-light bg-opacity-10 d-flex h-100 flex-column gap-1 p-1">
                                                        <span class="d-block p-1 px-2 bg-light bg-opacity-10 rounded mb-2"></span>
                                                        <span class="d-block p-1 px-2 pb-0 bg-light bg-opacity-10"></span>
                                                        <span class="d-block p-1 px-2 pb-0 bg-light bg-opacity-10"></span>
                                                        <span class="d-block p-1 px-2 pb-0 bg-light bg-opacity-10"></span>
                                                    </span>
                                                </span>
                                                <span class="flex-grow-1">
                                                    <span class="d-flex h-100 flex-column">
                                                        <span class="bg-light bg-opacity-10 d-block p-1"></span>
                                                        <span class="bg-light bg-opacity-10 d-block p-1 mt-auto"></span>
                                                    </span>
                                                </span>
                                            </span>
                                        </label>
                                    </div>
                                    <h5 class="fs-14 text-center mt-2">Dark</h5>
                                </div>
                            </div>
                        </div>

                        <div id="layout-width">
                            <h6 class="mt-4 mb-1 fs-15 fw-semibold text-uppercase">Layout Width</h6>
                            <p class="text-muted">Choose Fluid or Boxed layout.</p>

                            <div class="row gy-3">
                                <div class="col-6">
                                    <div class="form-check card-radio customize-widget" data-bs-toggle="collapse" data-bs-target="#collapseLayoutWidth.show">
                                        <input class="form-check-input" type="radio" name="data-layout-width" id="layout-width-fluid" value="fluid">
                                        <label class="form-check-label p-0 avatar-xl w-100" for="layout-width-fluid">
                                            <span class="customize-penal-main w-100 d-block d-flex align-items-center">
                                                <span class="d-flex align-items-center gap-1 ps-1">
                                                    <span class="d-inline-block badge p-0 text-bg-danger rounded-circle"></span>
                                                    <span class="d-inline-block badge p-0 text-bg-success rounded-circle"></span>
                                                    <span class="d-inline-block badge p-0 text-bg-warning rounded-circle"></span>
                                                </span>
                                            </span>
                                            <span class="d-flex gap-1 h-100">
                                                <span class="flex-shrink-0">
                                                    <span class="bg-light d-flex h-100 flex-column gap-1 p-1">
                                                        <span class="d-block p-1 px-2 bg-primary-subtle rounded mb-2"></span>
                                                        <span class="d-block p-1 px-2 pb-0 bg-primary-subtle"></span>
                                                        <span class="d-block p-1 px-2 pb-0 bg-primary-subtle"></span>
                                                        <span class="d-block p-1 px-2 pb-0 bg-primary-subtle"></span>
                                                    </span>
                                                </span>
                                                <span class="flex-grow-1">
                                                    <span class="d-flex h-100 flex-column">
                                                        <span class="bg-light d-block p-1"></span>
                                                        <span class="bg-light d-block p-1 mt-auto"></span>
                                                    </span>
                                                </span>
                                            </span>
                                        </label>
                                    </div>
                                    <h5 class="fs-14 text-center mt-2">Fluid</h5>
                                </div>
                                <div class="col-6">
                                    <div class="form-check card-radio customize-widget collapsed" data-bs-toggle="collapse" data-bs-target="#collapseLayoutWidth">
                                        <input class="form-check-input" type="radio" name="data-layout-width" id="layout-width-boxed" value="boxed">
                                        <label class="form-check-label p-0 avatar-xl w-100" for="layout-width-boxed">
                                            <span class="customize-penal-main w-100 d-block d-flex align-items-center">
                                                <span class="d-flex align-items-center gap-1 ps-1">
                                                    <span class="d-inline-block badge p-0 text-bg-danger rounded-circle"></span>
                                                    <span class="d-inline-block badge p-0 text-bg-success rounded-circle"></span>
                                                    <span class="d-inline-block badge p-0 text-bg-warning rounded-circle"></span>
                                                </span>
                                            </span>
                                            <span class="d-flex gap-1 h-100 border-start border-end px-3">
                                                <span class="flex-shrink-0">
                                                    <span class="bg-light d-flex h-100 flex-column gap-1 p-1">
                                                        <span class="d-block p-1 px-2 bg-primary-subtle rounded mb-2"></span>
                                                        <span class="d-block p-1 px-2 pb-0 bg-primary-subtle"></span>
                                                        <span class="d-block p-1 px-2 pb-0 bg-primary-subtle"></span>
                                                        <span class="d-block p-1 px-2 pb-0 bg-primary-subtle"></span>
                                                    </span>
                                                </span>
                                                <span class="flex-grow-1">
                                                    <span class="d-flex h-100 flex-column">
                                                        <span class="bg-light d-block p-1"></span>
                                                        <span class="bg-light d-block p-1 mt-auto"></span>
                                                    </span>
                                                </span>
                                            </span>
                                        </label>
                                    </div>
                                    <h5 class="fs-14 text-center mt-2">Boxed</h5>
                                </div>
                            </div>
                        </div>

                        <div class="collapse" id="collapseLayoutWidth">
                            <h6 class="mt-4 mb-1 fs-15 fw-semibold text-uppercase">Boxed Layout Body Images</h6>
                            <p class="text-muted">Choose image.</p>
                
                            <div class="row gy-3">
                                <div class="col-6">
                                    <div class="form-check card-radio customize-widget">
                                        <input class="form-check-input" type="radio" name="data-body-image" id="data-body-image-none" value="none">
                                        <label class="form-check-label p-0 avatar-xl w-100" for="data-body-image-none">
                                            <span class="customize-penal-main w-100 d-block d-flex align-items-center">
                                                <span class="d-flex align-items-center gap-1 ps-1">
                                                    <span class="d-inline-block badge p-0 text-bg-danger rounded-circle"></span>
                                                    <span class="d-inline-block badge p-0 text-bg-success rounded-circle"></span>
                                                    <span class="d-inline-block badge p-0 text-bg-warning rounded-circle"></span>
                                                </span>
                                            </span>
                                            <span class="d-flex gap-1 h-100 border-start border-end px-3">
                                            </span>
                                        </label>
                                    </div>
                                    <h5 class="fs-14 text-center mt-2">None</h5>
                                </div><!--end col-->
                                <div class="col-6">
                                    <div class="form-check card-radio customize-widget">
                                        <input class="form-check-input" type="radio" name="data-body-image" id="data-body-image-1" value="img-1">
                                        <label class="form-check-label p-0 avatar-xl w-100" for="data-body-image-1">
                                            <span class="customize-penal-main w-100 d-block d-flex align-items-center">
                                                <span class="d-flex align-items-center gap-1 ps-1">
                                                    <span class="d-inline-block badge p-0 text-bg-danger rounded-circle"></span>
                                                    <span class="d-inline-block badge p-0 text-bg-success rounded-circle"></span>
                                                    <span class="d-inline-block badge p-0 text-bg-warning rounded-circle"></span>
                                                </span>
                                            </span>
                                            <span class="d-flex gap-1 h-100 border-start border-end px-3" style="background-image: url('dashboard/assets/images/sidebar/body-light-1.png');">
                                            </span>
                                        </label>
                                    </div>
                                    <h5 class="fs-14 text-center mt-2">Img 1</h5>
                                </div><!--end col-->
                                <div class="col-6">
                                    <div class="form-check card-radio customize-widget">
                                        <input class="form-check-input" type="radio" name="data-body-image" id="data-body-image-2" value="img-2">
                                        <label class="form-check-label p-0 avatar-xl w-100" for="data-body-image-2">
                                            <span class="customize-penal-main w-100 d-block d-flex align-items-center">
                                                <span class="d-flex align-items-center gap-1 ps-1">
                                                    <span class="d-inline-block badge p-0 text-bg-danger rounded-circle"></span>
                                                    <span class="d-inline-block badge p-0 text-bg-success rounded-circle"></span>
                                                    <span class="d-inline-block badge p-0 text-bg-warning rounded-circle"></span>
                                                </span>
                                            </span>
                                            <span class="d-flex gap-1 h-100 border-start border-end px-3" style="background-image: url('dashboard/assets/images/sidebar/body-light-2.png');">
                                            </span>
                                        </label>
                                    </div>
                                    <h5 class="fs-14 text-center mt-2">Img 2</h5>
                                </div><!--end col-->
                                <div class="col-6">
                                    <div class="form-check card-radio customize-widget">
                                        <input class="form-check-input" type="radio" name="data-body-image" id="data-body-image-3" value="img-3">
                                        <label class="form-check-label p-0 avatar-xl w-100" for="data-body-image-3">
                                            <span class="customize-penal-main w-100 d-block d-flex align-items-center">
                                                <span class="d-flex align-items-center gap-1 ps-1">
                                                    <span class="d-inline-block badge p-0 text-bg-danger rounded-circle"></span>
                                                    <span class="d-inline-block badge p-0 text-bg-success rounded-circle"></span>
                                                    <span class="d-inline-block badge p-0 text-bg-warning rounded-circle"></span>
                                                </span>
                                            </span>
                                            <span class="d-flex gap-1 h-100 border-start border-end px-3" style="background-image: url('dashboard/assets/images/sidebar/body-light-3.png');">
                                            </span>
                                        </label>
                                    </div>
                                    <h5 class="fs-14 text-center mt-2">Img 3</h5>
                                </div><!--end col-->
                            </div><!--end row-->
                        </div>

                        <div id="layout-position">
                            <h6 class="mt-4 mb-1 fs-15 fw-semibold text-uppercase">Layout Position</h6>
                            <p class="text-muted">Choose Fixed or Scrollable Layout Position.</p>

                            <div class="btn-group radio" role="group">
                                <input type="radio" class="btn-check" name="data-layout-position" id="layout-position-fixed" value="fixed">
                                <label class="btn btn-light w-sm" for="layout-position-fixed">Fixed</label>

                                <input type="radio" class="btn-check" name="data-layout-position" id="layout-position-scrollable" value="scrollable">
                                <label class="btn btn-light w-sm ms-0" for="layout-position-scrollable">Scrollable</label>
                            </div>
                        </div>
                        <h6 class="mt-4 mb-1 fs-15 fw-semibold text-uppercase">Topbar Color</h6>
                        <p class="text-muted">Choose Light or Dark Topbar Color.</p>

                        <div class="row gy-3">
                            <div class="col-6">
                                <div class="form-check card-radio customize-widget">
                                    <input class="form-check-input" type="radio" name="data-topbar" id="topbar-color-light" value="light">
                                    <label class="form-check-label p-0 avatar-xl w-100" for="topbar-color-light">
                                        <span class="customize-penal-main w-100 d-block d-flex align-items-center">
                                            <span class="d-flex align-items-center gap-1 ps-1">
                                                <span class="d-inline-block badge p-0 text-bg-danger rounded-circle"></span>
                                                <span class="d-inline-block badge p-0 text-bg-success rounded-circle"></span>
                                                <span class="d-inline-block badge p-0 text-bg-warning rounded-circle"></span>
                                            </span>
                                        </span>
                                        <span class="d-flex gap-1 h-100">
                                            <span class="flex-shrink-0">
                                                <span class="bg-light d-flex h-100 flex-column gap-1 p-1">
                                                    <span class="d-block p-1 px-2 bg-primary-subtle rounded mb-2"></span>
                                                    <span class="d-block p-1 px-2 pb-0 bg-primary-subtle"></span>
                                                    <span class="d-block p-1 px-2 pb-0 bg-primary-subtle"></span>
                                                    <span class="d-block p-1 px-2 pb-0 bg-primary-subtle"></span>
                                                </span>
                                            </span>
                                            <span class="flex-grow-1">
                                                <span class="d-flex h-100 flex-column">
                                                    <span class="bg-light d-block p-1"></span>
                                                    <span class="bg-light d-block p-1 mt-auto"></span>
                                                </span>
                                            </span>
                                        </span>
                                    </label>
                                </div>
                                <h5 class="fs-14 text-center mt-2">Light</h5>
                            </div>
                            <div class="col-6">
                                <div class="form-check card-radio customize-widget">
                                    <input class="form-check-input" type="radio" name="data-topbar" id="topbar-color-dark" value="dark">
                                    <label class="form-check-label p-0 avatar-xl w-100" for="topbar-color-dark">
                                        <span class="customize-penal-main w-100 d-block d-flex align-items-center">
                                            <span class="d-flex align-items-center gap-1 ps-1">
                                                <span class="d-inline-block badge p-0 text-bg-danger rounded-circle"></span>
                                                <span class="d-inline-block badge p-0 text-bg-success rounded-circle"></span>
                                                <span class="d-inline-block badge p-0 text-bg-warning rounded-circle"></span>
                                            </span>
                                        </span>
                                        <span class="d-flex gap-1 h-100">
                                            <span class="flex-shrink-0">
                                                <span class="bg-light d-flex h-100 flex-column gap-1 p-1">
                                                    <span class="d-block p-1 px-2 bg-primary-subtle rounded mb-2"></span>
                                                    <span class="d-block p-1 px-2 pb-0 bg-primary-subtle"></span>
                                                    <span class="d-block p-1 px-2 pb-0 bg-primary-subtle"></span>
                                                    <span class="d-block p-1 px-2 pb-0 bg-primary-subtle"></span>
                                                </span>
                                            </span>
                                            <span class="flex-grow-1">
                                                <span class="d-flex h-100 flex-column">
                                                    <span class="bg-dark d-block p-1"></span>
                                                    <span class="bg-light d-block p-1 mt-auto"></span>
                                                </span>
                                            </span>
                                        </span>
                                    </label>
                                </div>
                                <h5 class="fs-14 text-center mt-2">Dark</h5>
                            </div>

                            <div class="col-6">
                                <div class="form-check card-radio customize-widget">
                                    <input class="form-check-input" type="radio" name="data-topbar" id="topbar-color-brand" value="brand">
                                    <label class="form-check-label p-0 avatar-xl w-100" for="topbar-color-brand">
                                        <span class="customize-penal-main w-100 d-block d-flex align-items-center">
                                            <span class="d-flex align-items-center gap-1 ps-1">
                                                <span class="d-inline-block badge p-0 text-bg-danger rounded-circle"></span>
                                                <span class="d-inline-block badge p-0 text-bg-success rounded-circle"></span>
                                                <span class="d-inline-block badge p-0 text-bg-warning rounded-circle"></span>
                                            </span>
                                        </span>
                                        <span class="d-flex gap-1 h-100">
                                            <span class="flex-shrink-0">
                                                <span class="bg-light d-flex h-100 flex-column gap-1 p-1">
                                                    <span class="d-block p-1 px-2 bg-primary-subtle rounded mb-2"></span>
                                                    <span class="d-block p-1 px-2 pb-0 bg-primary-subtle"></span>
                                                    <span class="d-block p-1 px-2 pb-0 bg-primary-subtle"></span>
                                                    <span class="d-block p-1 px-2 pb-0 bg-primary-subtle"></span>
                                                </span>
                                            </span>
                                            <span class="flex-grow-1">
                                                <span class="d-flex h-100 flex-column">
                                                    <span class="bg-primary d-block p-1"></span>
                                                    <span class="bg-light d-block p-1 mt-auto"></span>
                                                </span>
                                            </span>
                                        </span>
                                    </label>
                                </div>
                                <h5 class="fs-14 text-center mt-2">Brand</h5>
                            </div>
                        </div>

                        <div id="sidebar-size">
                            <h6 class="mt-4 mb-1 fs-15 fw-semibold text-uppercase">Sidebar Size</h6>
                            <p class="text-muted">Choose a size of Sidebar.</p>

                            <div class="row gy-3">
                                <div class="col-6">
                                    <div class="form-check sidebar-setting card-radio customize-widget">
                                        <input class="form-check-input" type="radio" name="data-sidebar-size" id="sidebar-size-default" value="lg">
                                        <label class="form-check-label p-0 avatar-xl w-100" for="sidebar-size-default">
                                            <span class="customize-penal-main w-100 d-block d-flex align-items-center">
                                                <span class="d-flex align-items-center gap-1 ps-1">
                                                    <span class="d-inline-block badge p-0 text-bg-danger rounded-circle"></span>
                                                    <span class="d-inline-block badge p-0 text-bg-success rounded-circle"></span>
                                                    <span class="d-inline-block badge p-0 text-bg-warning rounded-circle"></span>
                                                </span>
                                            </span>
                                            <span class="d-flex gap-1 h-100">
                                                <span class="flex-shrink-0">
                                                    <span class="bg-light d-flex h-100 flex-column gap-1 p-1">
                                                        <span class="d-block p-1 px-2 bg-primary-subtle rounded mb-2"></span>
                                                        <span class="d-block p-1 px-2 pb-0 bg-primary-subtle"></span>
                                                        <span class="d-block p-1 px-2 pb-0 bg-primary-subtle"></span>
                                                        <span class="d-block p-1 px-2 pb-0 bg-primary-subtle"></span>
                                                    </span>
                                                </span>
                                                <span class="flex-grow-1">
                                                    <span class="d-flex h-100 flex-column">
                                                        <span class="bg-light d-block p-1"></span>
                                                        <span class="bg-light d-block p-1 mt-auto"></span>
                                                    </span>
                                                </span>
                                            </span>
                                        </label>
                                    </div>
                                    <h5 class="fs-14 text-center mt-2">Default</h5>
                                </div>

                                <div class="col-6">
                                    <div class="form-check sidebar-setting card-radio customize-widget">
                                        <input class="form-check-input" type="radio" name="data-sidebar-size" id="sidebar-size-compact" value="md">
                                        <label class="form-check-label p-0 avatar-xl w-100" for="sidebar-size-compact">
                                            <span class="customize-penal-main w-100 d-block d-flex align-items-center">
                                                <span class="d-flex align-items-center gap-1 ps-1">
                                                    <span class="d-inline-block badge p-0 text-bg-danger rounded-circle"></span>
                                                    <span class="d-inline-block badge p-0 text-bg-success rounded-circle"></span>
                                                    <span class="d-inline-block badge p-0 text-bg-warning rounded-circle"></span>
                                                </span>
                                            </span>
                                            <span class="d-flex gap-1 h-100">
                                                <span class="flex-shrink-0">
                                                    <span class="bg-light d-flex h-100 flex-column gap-1 p-1">
                                                        <span class="d-block p-1 bg-primary-subtle rounded mb-2"></span>
                                                        <span class="d-block p-1 pb-0 bg-primary-subtle"></span>
                                                        <span class="d-block p-1 pb-0 bg-primary-subtle"></span>
                                                        <span class="d-block p-1 pb-0 bg-primary-subtle"></span>
                                                    </span>
                                                </span>
                                                <span class="flex-grow-1">
                                                    <span class="d-flex h-100 flex-column">
                                                        <span class="bg-light d-block p-1"></span>
                                                        <span class="bg-light d-block p-1 mt-auto"></span>
                                                    </span>
                                                </span>
                                            </span>
                                        </label>
                                    </div>
                                    <h5 class="fs-14 text-center mt-2">Compact</h5>
                                </div>

                                <div class="col-6">
                                    <div class="form-check sidebar-setting card-radio customize-widget">
                                        <input class="form-check-input" type="radio" name="data-sidebar-size" id="sidebar-size-small" value="sm">
                                        <label class="form-check-label p-0 avatar-xl w-100" for="sidebar-size-small">
                                            <span class="customize-penal-main w-100 d-block d-flex align-items-center">
                                                <span class="d-flex align-items-center gap-1 ps-1">
                                                    <span class="d-inline-block badge p-0 text-bg-danger rounded-circle"></span>
                                                    <span class="d-inline-block badge p-0 text-bg-success rounded-circle"></span>
                                                    <span class="d-inline-block badge p-0 text-bg-warning rounded-circle"></span>
                                                </span>
                                            </span>
                                            <span class="d-flex gap-1 h-100">
                                                <span class="flex-shrink-0">
                                                    <span class="bg-light d-flex h-100 flex-column gap-1">
                                                        <span class="d-block p-1 bg-primary-subtle mb-2"></span>
                                                        <span class="d-block p-1 pb-0 bg-primary-subtle"></span>
                                                        <span class="d-block p-1 pb-0 bg-primary-subtle"></span>
                                                        <span class="d-block p-1 pb-0 bg-primary-subtle"></span>
                                                    </span>
                                                </span>
                                                <span class="flex-grow-1">
                                                    <span class="d-flex h-100 flex-column">
                                                        <span class="bg-light d-block p-1"></span>
                                                        <span class="bg-light d-block p-1 mt-auto"></span>
                                                    </span>
                                                </span>
                                            </span>
                                        </label>
                                    </div>
                                    <h5 class="fs-14 text-center mt-2">Small (Icon View)</h5>
                                </div>

                                <div class="col-6">
                                    <div class="form-check sidebar-setting card-radio customize-widget">
                                        <input class="form-check-input" type="radio" name="data-sidebar-size" id="sidebar-size-small-hover" value="sm-hover">
                                        <label class="form-check-label p-0 avatar-xl w-100" for="sidebar-size-small-hover">
                                            <span class="customize-penal-main w-100 d-block d-flex align-items-center">
                                                <span class="d-flex align-items-center gap-1 ps-1">
                                                    <span class="d-inline-block badge p-0 text-bg-danger rounded-circle"></span>
                                                    <span class="d-inline-block badge p-0 text-bg-success rounded-circle"></span>
                                                    <span class="d-inline-block badge p-0 text-bg-warning rounded-circle"></span>
                                                </span>
                                            </span>
                                            <span class="d-flex gap-1 h-100">
                                                <span class="flex-shrink-0">
                                                    <span class="bg-light d-flex h-100 flex-column gap-1">
                                                        <span class="d-block p-1 bg-primary-subtle mb-2"></span>
                                                        <span class="d-block p-1 pb-0 bg-primary-subtle"></span>
                                                        <span class="d-block p-1 pb-0 bg-primary-subtle"></span>
                                                        <span class="d-block p-1 pb-0 bg-primary-subtle"></span>
                                                    </span>
                                                </span>
                                                <span class="flex-grow-1">
                                                    <span class="d-flex h-100 flex-column">
                                                        <span class="bg-light d-block p-1"></span>
                                                        <span class="bg-light d-block p-1 mt-auto"></span>
                                                    </span>
                                                </span>
                                            </span>
                                        </label>
                                    </div>
                                    <h5 class="fs-14 text-center mt-2">Small Hover View</h5>
                                </div>
                            </div>
                        </div>

                        <div id="sidebar-view">
                            <h6 class="mt-4 mb-1 fs-15 fw-semibold text-uppercase">Sidebar View</h6>
                            <p class="text-muted">Choose Default or Detached Sidebar view.</p>

                            <div class="row gy-3">
                                <div class="col-6">
                                    <div class="form-check sidebar-setting card-radio customize-widget">
                                        <input class="form-check-input" type="radio" name="data-layout-style" id="sidebar-view-default" value="default">
                                        <label class="form-check-label p-0 avatar-xl w-100" for="sidebar-view-default">
                                            <span class="customize-penal-main w-100 d-block d-flex align-items-center">
                                                <span class="d-flex align-items-center gap-1 ps-1">
                                                    <span class="d-inline-block badge p-0 text-bg-danger rounded-circle"></span>
                                                    <span class="d-inline-block badge p-0 text-bg-success rounded-circle"></span>
                                                    <span class="d-inline-block badge p-0 text-bg-warning rounded-circle"></span>
                                                </span>
                                            </span>
                                            <span class="d-flex gap-1 h-100">
                                                <span class="flex-shrink-0">
                                                    <span class="bg-light d-flex h-100 flex-column gap-1 p-1">
                                                        <span class="d-block p-1 px-2 bg-primary-subtle rounded mb-2"></span>
                                                        <span class="d-block p-1 px-2 pb-0 bg-primary-subtle"></span>
                                                        <span class="d-block p-1 px-2 pb-0 bg-primary-subtle"></span>
                                                        <span class="d-block p-1 px-2 pb-0 bg-primary-subtle"></span>
                                                    </span>
                                                </span>
                                                <span class="flex-grow-1">
                                                    <span class="d-flex h-100 flex-column">
                                                        <span class="bg-light d-block p-1"></span>
                                                        <span class="bg-light d-block p-1 mt-auto"></span>
                                                    </span>
                                                </span>
                                            </span>
                                        </label>
                                    </div>
                                    <h5 class="fs-14 text-center mt-2">Default</h5>
                                </div>
                                <div class="col-6">
                                    <div class="form-check sidebar-setting card-radio customize-widget">
                                        <input class="form-check-input" type="radio" name="data-layout-style" id="sidebar-view-detached" value="detached">
                                        <label class="form-check-label p-0 avatar-xl w-100" for="sidebar-view-detached">
                                            <span class="customize-penal-main w-100 d-block d-flex align-items-center">
                                                <span class="d-flex align-items-center gap-1 ps-1">
                                                    <span class="d-inline-block badge p-0 text-bg-danger rounded-circle"></span>
                                                    <span class="d-inline-block badge p-0 text-bg-success rounded-circle"></span>
                                                    <span class="d-inline-block badge p-0 text-bg-warning rounded-circle"></span>
                                                </span>
                                            </span>
                                            <span class="d-flex h-100 flex-column">
                                                <span class="bg-light d-flex p-1 gap-1 align-items-center px-2">
                                                    <span class="d-block p-1 bg-primary-subtle rounded me-1"></span>
                                                    <span class="d-block p-1 pb-0 px-2 bg-primary-subtle ms-auto"></span>
                                                    <span class="d-block p-1 pb-0 px-2 bg-primary-subtle"></span>
                                                </span>
                                                <span class="d-flex gap-1 h-100 p-1 px-2">
                                                    <span class="flex-shrink-0">
                                                        <span class="bg-light d-flex h-100 flex-column gap-1 p-1">
                                                            <span class="d-block p-1 px-2 pb-0 bg-primary-subtle"></span>
                                                            <span class="d-block p-1 px-2 pb-0 bg-primary-subtle"></span>
                                                            <span class="d-block p-1 px-2 pb-0 bg-primary-subtle"></span>
                                                        </span>
                                                    </span>
                                                </span>
                                                <span class="bg-light d-block p-1 mt-auto px-2"></span>
                                            </span>
                                        </label>
                                    </div>
                                    <h5 class="fs-14 text-center mt-2">Detached</h5>
                                </div>
                            </div>
                        </div>
                        <div id="sidebar-color">
                            <h6 class="mt-4 mb-1 fs-15 fw-semibold text-uppercase">Sidebar Color</h6>
                            <p class="text-muted">Choose a color of Sidebar.</p>

                            <div class="row gy-3">
                                <div class="col-6">
                                    <div class="form-check sidebar-setting card-radio customize-widget" data-bs-toggle="collapse" data-bs-target="#collapseBgGradient.show">
                                        <input class="form-check-input" type="radio" name="data-sidebar" id="sidebar-color-light" value="light">
                                        <label class="form-check-label p-0 avatar-xl w-100" for="sidebar-color-light">
                                            <span class="customize-penal-main w-100 d-block d-flex align-items-center">
                                                <span class="d-flex align-items-center gap-1 ps-1">
                                                    <span class="d-inline-block badge p-0 text-bg-danger rounded-circle"></span>
                                                    <span class="d-inline-block badge p-0 text-bg-success rounded-circle"></span>
                                                    <span class="d-inline-block badge p-0 text-bg-warning rounded-circle"></span>
                                                </span>
                                            </span>
                                            <span class="d-flex gap-1 h-100">
                                                <span class="flex-shrink-0">
                                                    <span class="bg-white border-end d-flex h-100 flex-column gap-1 p-1">
                                                        <span class="d-block p-1 px-2 bg-primary-subtle rounded mb-2"></span>
                                                        <span class="d-block p-1 px-2 pb-0 bg-primary-subtle"></span>
                                                        <span class="d-block p-1 px-2 pb-0 bg-primary-subtle"></span>
                                                        <span class="d-block p-1 px-2 pb-0 bg-primary-subtle"></span>
                                                    </span>
                                                </span>
                                                <span class="flex-grow-1">
                                                    <span class="d-flex h-100 flex-column">
                                                        <span class="bg-light d-block p-1"></span>
                                                        <span class="bg-light d-block p-1 mt-auto"></span>
                                                    </span>
                                                </span>
                                            </span>
                                        </label>
                                    </div>
                                    <h5 class="fs-14 text-center mt-2">Light</h5>
                                </div>
                                <div class="col-6">
                                    <div class="form-check sidebar-setting card-radio customize-widget" data-bs-toggle="collapse" data-bs-target="#collapseBgGradient.show">
                                        <input class="form-check-input" type="radio" name="data-sidebar" id="sidebar-color-dark" value="dark">
                                        <label class="form-check-label p-0 avatar-xl w-100" for="sidebar-color-dark">
                                            <span class="customize-penal-main w-100 d-block d-flex align-items-center">
                                                <span class="d-flex align-items-center gap-1 ps-1">
                                                    <span class="d-inline-block badge p-0 text-bg-danger rounded-circle"></span>
                                                    <span class="d-inline-block badge p-0 text-bg-success rounded-circle"></span>
                                                    <span class="d-inline-block badge p-0 text-bg-warning rounded-circle"></span>
                                                </span>
                                            </span>
                                            <span class="d-flex gap-1 h-100">
                                                <span class="flex-shrink-0">
                                                    <span class="bg-dark d-flex h-100 flex-column gap-1 p-1">
                                                        <span class="d-block p-1 px-2 bg-light bg-opacity-10 rounded mb-2"></span>
                                                        <span class="d-block p-1 px-2 pb-0 bg-light bg-opacity-10"></span>
                                                        <span class="d-block p-1 px-2 pb-0 bg-light bg-opacity-10"></span>
                                                        <span class="d-block p-1 px-2 pb-0 bg-light bg-opacity-10"></span>
                                                    </span>
                                                </span>
                                                <span class="flex-grow-1">
                                                    <span class="d-flex h-100 flex-column">
                                                        <span class="bg-light d-block p-1"></span>
                                                        <span class="bg-light d-block p-1 mt-auto"></span>
                                                    </span>
                                                </span>
                                            </span>
                                        </label>
                                    </div>
                                    <h5 class="fs-14 text-center mt-2">Dark</h5>
                                </div>
                                <div class="col-6">
                                    <button class="btn btn-link avatar-xl w-100 p-0 overflow-hidden border collapsed customize-widget" type="button" data-bs-toggle="collapse" data-bs-target="#collapseBgGradient" aria-expanded="false" aria-controls="collapseBgGradient">
                                        <span class="customize-penal-main w-100 d-block d-flex align-items-center">
                                            <span class="d-flex align-items-center gap-1 ps-1">
                                                <span class="d-inline-block badge p-0 text-bg-danger rounded-circle"></span>
                                                <span class="d-inline-block badge p-0 text-bg-success rounded-circle"></span>
                                                <span class="d-inline-block badge p-0 text-bg-warning rounded-circle"></span>
                                            </span>
                                        </span>
                                        <span class="d-flex gap-1 h-100">
                                            <span class="flex-shrink-0">
                                                <span class="bg-vertical-gradient d-flex h-100 flex-column gap-1 p-1">
                                                    <span class="d-block p-1 px-2 bg-light bg-opacity-10 rounded mb-2"></span>
                                                    <span class="d-block p-1 px-2 pb-0 bg-white bg-opacity-10"></span>
                                                    <span class="d-block p-1 px-2 pb-0 bg-white bg-opacity-10"></span>
                                                    <span class="d-block p-1 px-2 pb-0 bg-white bg-opacity-10"></span>
                                                </span>
                                            </span>
                                            <span class="flex-grow-1">
                                                <span class="d-flex h-100 flex-column">
                                                    <span class="bg-light d-block p-1"></span>
                                                    <span class="bg-light d-block p-1 mt-auto"></span>
                                                </span>
                                            </span>
                                        </span>
                                    </button>
                                    <h5 class="fs-14 text-center mt-2">Gradient</h5>
                                </div>
                            </div>
                            <!-- end row -->

                            <div class="collapse" id="collapseBgGradient">
                                <div class="d-flex gap-2 flex-wrap img-switch p-2 px-3 bg-light rounded">

                                    <div class="form-check sidebar-setting card-radio">
                                        <input class="form-check-input" type="radio" name="data-sidebar" id="sidebar-color-gradient" value="gradient">
                                        <label class="form-check-label p-0 avatar-xs rounded-circle" for="sidebar-color-gradient">
                                            <span class="avatar-title rounded-circle bg-vertical-gradient"></span>
                                        </label>
                                    </div>
                                    <div class="form-check sidebar-setting card-radio">
                                        <input class="form-check-input" type="radio" name="data-sidebar" id="sidebar-color-gradient-2" value="gradient-2">
                                        <label class="form-check-label p-0 avatar-xs rounded-circle" for="sidebar-color-gradient-2">
                                            <span class="avatar-title rounded-circle bg-vertical-gradient-2"></span>
                                        </label>
                                    </div>
                                    <div class="form-check sidebar-setting card-radio">
                                        <input class="form-check-input" type="radio" name="data-sidebar" id="sidebar-color-gradient-3" value="gradient-3">
                                        <label class="form-check-label p-0 avatar-xs rounded-circle" for="sidebar-color-gradient-3">
                                            <span class="avatar-title rounded-circle bg-vertical-gradient-3"></span>
                                        </label>
                                    </div>
                                    <div class="form-check sidebar-setting card-radio">
                                        <input class="form-check-input" type="radio" name="data-sidebar" id="sidebar-color-gradient-4" value="gradient-4">
                                        <label class="form-check-label p-0 avatar-xs rounded-circle" for="sidebar-color-gradient-4">
                                            <span class="avatar-title rounded-circle bg-vertical-gradient-4"></span>
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div id="sidebar-img">
                            <h6 class="mt-4 mb-1 fs-15 fw-semibold text-uppercase">Sidebar Images</h6>
                            <p class="text-muted">Choose a image of Sidebar.</p>

                    
                            <div class="img-switch">
                                <div class="row gy-3">
                                    <div class="col-6">
                                        <div class="form-check sidebar-setting card-radio customize-widget">
                                            <input class="form-check-input" type="radio" name="data-sidebar-image" id="sidebarimg-none" value="none">
                                            <label class="form-check-label p-0 avatar-xl w-100" for="sidebarimg-none">
                                                <span class="customize-penal-main w-100 d-block d-flex align-items-center">
                                                    <span class="d-flex align-items-center gap-1 ps-1">
                                                        <span class="d-inline-block badge p-0 text-bg-danger rounded-circle"></span>
                                                        <span class="d-inline-block badge p-0 text-bg-success rounded-circle"></span>
                                                        <span class="d-inline-block badge p-0 text-bg-warning rounded-circle"></span>
                                                    </span>
                                                </span>
                                                <span class="d-flex gap-1 h-100">
                                                    <span class="flex-shrink-0">
                                                        <span class="bg-light d-flex h-100 flex-column gap-1 p-2 d-flex align-items-center justify-content-center">
                                                            <i class="ri-close-fill fs-20"></i>
                                                        </span>
                                                    </span>
                                                    <span class="flex-grow-1">
                                                        <span class="d-flex h-100 flex-column">
                                                            <span class="bg-light d-block p-1"></span>
                                                            <span class="bg-light d-block p-1 mt-auto"></span>
                                                        </span>
                                                    </span>
                                                </span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="form-check sidebar-setting card-radio customize-widget">
                                            <input class="form-check-input" type="radio" name="data-sidebar-image" id="sidebarimg-01" value="img-1">
                                            <label class="form-check-label p-0 avatar-xl w-100" for="sidebarimg-01">
                                                <span class="customize-penal-main w-100 d-block d-flex align-items-center">
                                                    <span class="d-flex align-items-center gap-1 ps-1">
                                                        <span class="d-inline-block badge p-0 text-bg-danger rounded-circle"></span>
                                                        <span class="d-inline-block badge p-0 text-bg-success rounded-circle"></span>
                                                        <span class="d-inline-block badge p-0 text-bg-warning rounded-circle"></span>
                                                    </span>
                                                </span>
                                                <span class="d-flex gap-1 h-100">
                                                    <span class="flex-shrink-0">
                                                        <img src="dashboard/assets/images/sidebar/img-1.jpg" alt="" class="avatar-sm h-100 object-fit-cover">
                                                    </span>
                                                    <span class="flex-grow-1">
                                                        <span class="d-flex h-100 flex-column">
                                                            <span class="bg-light d-block p-1"></span>
                                                            <span class="bg-light d-block p-1 mt-auto"></span>
                                                        </span>
                                                    </span>
                                                </span>
                                            </label>
                                        </div>
                                    </div><!--end col-->
                                    <div class="col-6">
                                        <div class="form-check sidebar-setting card-radio customize-widget">
                                            <input class="form-check-input" type="radio" name="data-sidebar-image" id="sidebarimg-02" value="img-2">
                                            <label class="form-check-label p-0 avatar-xl w-100" for="sidebarimg-02">
                                                <span class="customize-penal-main w-100 d-block d-flex align-items-center">
                                                    <span class="d-flex align-items-center gap-1 ps-1">
                                                        <span class="d-inline-block badge p-0 text-bg-danger rounded-circle"></span>
                                                        <span class="d-inline-block badge p-0 text-bg-success rounded-circle"></span>
                                                        <span class="d-inline-block badge p-0 text-bg-warning rounded-circle"></span>
                                                    </span>
                                                </span>
                                                <span class="d-flex gap-1 h-100">
                                                    <span class="flex-shrink-0">
                                                        <img src="dashboard/assets/images/sidebar/img-2.jpg" alt="" class="avatar-sm h-100 object-fit-cover">
                                                    </span>
                                                    <span class="flex-grow-1">
                                                        <span class="d-flex h-100 flex-column">
                                                            <span class="bg-light d-block p-1"></span>
                                                            <span class="bg-light d-block p-1 mt-auto"></span>
                                                        </span>
                                                    </span>
                                                </span>
                                            </label>
                                        </div>
                                    </div><!--end col-->
                                    <div class="col-6">
                                        <div class="form-check sidebar-setting card-radio customize-widget">
                                            <input class="form-check-input" type="radio" name="data-sidebar-image" id="sidebarimg-03" value="img-3">
                                            <label class="form-check-label p-0 avatar-xl w-100" for="sidebarimg-03">
                                                <span class="customize-penal-main w-100 d-block d-flex align-items-center">
                                                    <span class="d-flex align-items-center gap-1 ps-1">
                                                        <span class="d-inline-block badge p-0 text-bg-danger rounded-circle"></span>
                                                        <span class="d-inline-block badge p-0 text-bg-success rounded-circle"></span>
                                                        <span class="d-inline-block badge p-0 text-bg-warning rounded-circle"></span>
                                                    </span>
                                                </span>
                                                <span class="d-flex gap-1 h-100">
                                                    <span class="flex-shrink-0">
                                                        <img src="dashboard/assets/images/sidebar/img-3.jpg" alt="" class="avatar-sm h-100 object-fit-cover">
                                                    </span>
                                                    <span class="flex-grow-1">
                                                        <span class="d-flex h-100 flex-column">
                                                            <span class="bg-light d-block p-1"></span>
                                                            <span class="bg-light d-block p-1 mt-auto"></span>
                                                        </span>
                                                    </span>
                                                </span>
                                            </label>
                                        </div>
                                    </div><!--end col-->
                                    <div class="col-6">
                                        <div class="form-check sidebar-setting card-radio customize-widget">
                                            <input class="form-check-input" type="radio" name="data-sidebar-image" id="sidebarimg-04" value="img-4">
                                            <label class="form-check-label p-0 avatar-xl w-100" for="sidebarimg-04">
                                                <span class="customize-penal-main w-100 d-block d-flex align-items-center">
                                                    <span class="d-flex align-items-center gap-1 ps-1">
                                                        <span class="d-inline-block badge p-0 text-bg-danger rounded-circle"></span>
                                                        <span class="d-inline-block badge p-0 text-bg-success rounded-circle"></span>
                                                        <span class="d-inline-block badge p-0 text-bg-warning rounded-circle"></span>
                                                    </span>
                                                </span>
                                                <span class="d-flex gap-1 h-100">
                                                    <span class="flex-shrink-0">
                                                        <img src="dashboard/assets/images/sidebar/img-4.jpg" alt="" class="avatar-sm h-100 object-fit-cover">
                                                    </span>
                                                    <span class="flex-grow-1">
                                                        <span class="d-flex h-100 flex-column">
                                                            <span class="bg-light d-block p-1"></span>
                                                            <span class="bg-light d-block p-1 mt-auto"></span>
                                                        </span>
                                                    </span>
                                                </span>
                                            </label>
                                        </div>
                                    </div><!--end col-->
                                </div><!--end row-->
                            </div>
                        </div>

                        <div id="preloader-menu">
                            <h6 class="mt-4 mb-1 fs-15 fw-semibold text-uppercase">Preloader</h6>
                            <p class="text-muted">Choose a preloader.</p>

                            <div class="row gy-3">
                                <div class="col-6">
                                    <div class="form-check sidebar-setting card-radio customize-widget">
                                        <input class="form-check-input" type="radio" name="data-preloader" id="preloader-view-custom" value="enable">
                                        <label class="form-check-label p-0 avatar-xl w-100" for="preloader-view-custom">
                                            <span class="customize-penal-main w-100 d-block d-flex align-items-center">
                                                <span class="d-flex align-items-center gap-1 ps-1">
                                                    <span class="d-inline-block badge p-0 text-bg-danger rounded-circle"></span>
                                                    <span class="d-inline-block badge p-0 text-bg-success rounded-circle"></span>
                                                    <span class="d-inline-block badge p-0 text-bg-warning rounded-circle"></span>
                                                </span>
                                            </span>
                                            <span class="d-flex gap-1 h-100">
                                                <span class="flex-shrink-0">
                                                    <span class="bg-light d-flex h-100 flex-column gap-1 p-1">
                                                        <span class="d-block p-1 px-2 bg-primary-subtle rounded mb-2"></span>
                                                        <span class="d-block p-1 px-2 pb-0 bg-primary-subtle"></span>
                                                        <span class="d-block p-1 px-2 pb-0 bg-primary-subtle"></span>
                                                        <span class="d-block p-1 px-2 pb-0 bg-primary-subtle"></span>
                                                    </span>
                                                </span>
                                                <span class="flex-grow-1">
                                                    <span class="d-flex h-100 flex-column">
                                                        <span class="bg-light d-block p-1"></span>
                                                        <span class="bg-light d-block p-1 mt-auto"></span>
                                                    </span>
                                                </span>
                                            </span>
                                            <!-- <div id="preloader"> -->
                                            <span class="d-flex align-items-center justify-content-center">
                                                <span class="spinner-border text-primary avatar-xxs m-auto" role="status">
                                                    <span class="visually-hidden">Loading...</span>
                                                </span>
                                            </span>
                                            <!-- </div> -->
                                        </label>
                                    </div>
                                    <h5 class="fs-14 text-center mt-2">Enable</h5>
                                </div>
                                <div class="col-6">
                                    <div class="form-check sidebar-setting card-radio customize-widget">
                                        <input class="form-check-input" type="radio" name="data-preloader" id="preloader-view-none" value="disable">
                                        <label class="form-check-label p-0 avatar-xl w-100" for="preloader-view-none">
                                            <span class="customize-penal-main w-100 d-block d-flex align-items-center">
                                                <span class="d-flex align-items-center gap-1 ps-1">
                                                    <span class="d-inline-block badge p-0 text-bg-danger rounded-circle"></span>
                                                    <span class="d-inline-block badge p-0 text-bg-success rounded-circle"></span>
                                                    <span class="d-inline-block badge p-0 text-bg-warning rounded-circle"></span>
                                                </span>
                                            </span>
                                            <span class="d-flex gap-1 h-100">
                                                <span class="flex-shrink-0">
                                                    <span class="bg-light d-flex h-100 flex-column gap-1 p-1">
                                                        <span class="d-block p-1 px-2 bg-primary-subtle rounded mb-2"></span>
                                                        <span class="d-block p-1 px-2 pb-0 bg-primary-subtle"></span>
                                                        <span class="d-block p-1 px-2 pb-0 bg-primary-subtle"></span>
                                                        <span class="d-block p-1 px-2 pb-0 bg-primary-subtle"></span>
                                                    </span>
                                                </span>
                                                <span class="flex-grow-1">
                                                    <span class="d-flex h-100 flex-column">
                                                        <span class="bg-light d-block p-1"></span>
                                                        <span class="bg-light d-block p-1 mt-auto"></span>
                                                    </span>
                                                </span>
                                            </span>
                                        </label>
                                    </div>
                                    <h5 class="fs-14 text-center mt-2">Disable</h5>
                                </div>
                            </div>

                        </div><!-- end preloader-menu -->
                    </div>
                </div>

            </div>
            <div class="offcanvas-footer border-top p-3 text-center">
                <div class="row">
                    <div class="col-6">
                        <button type="button" class="btn btn-light w-100" id="reset-layout">Reset</button>
                    </div>
                    <div class="col-6">
                        <a href="#!" target="_blank" class="btn btn-primary w-100">Buy Now</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- JAVASCRIPT -->
        <script src="dashboard/assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="dashboard/assets/libs/simplebar/simplebar.min.js"></script>
        <script src="dashboard/assets/js/plugins.js"></script>

        <!-- apexcharts -->
        <script src="dashboard/assets/libs/apexcharts/apexcharts.min.js"></script>

        <!-- Vector map-->
        <script src="dashboard/assets/libs/jsvectormap/js/jsvectormap.min.js"></script>
        <script src="dashboard/assets/libs/jsvectormap/maps/world-merc.js"></script>

        <script src="dashboard/assets/libs/list.js/list.min.js"></script>

        <!--Swiper slider js-->
        <script src="dashboard/assets/libs/swiper/swiper-bundle.min.js"></script>

        <!-- Dashboard init -->
        <script src="dashboard/assets/js/pages/dashboard-ecommerce.init.js"></script>

        <!-- App js -->
        <script src="dashboard/assets/js/app.js"></script>

        <script>
            //  Line chart datalabel
                var linechartDatalabelColors = getChartColorsArray("line_chart_datalabel");
                if (linechartDatalabelColors) {
                    var options = {
                        chart: {
                            height: 405,
                            zoom: {
                                enabled: true
                            },
                            toolbar: {
                                show: false
                            }
                        },
                        colors: linechartDatalabelColors,
                        markers: {
                            size: 0,
                            colors: "#ffffff",
                            strokeColors: linechartDatalabelColors,
                            strokeWidth: 1,
                            strokeOpacity: 0.9,
                            fillOpacity: 1,
                        },
                        dataLabels: {
                            enabled: false,
                        },
                        stroke: {
                            width: [2, 2, 2],
                            curve: 'smooth'
                        },
                        series: [{
                            name: "Orders",
                            type: 'line',
                            data: [180, 274, 346, 290, 370, 420, 490, 542, 510, 580, 636, 745]
                        },
                        {
                            name: "Refunds",
                            type: 'area',
                            data: [100, 154, 302, 411, 300, 284, 273, 232, 187, 174, 152, 122]
                        },
                        {
                            name: "Earnings",
                            type: 'line',
                            data: [260, 360, 320, 345, 436, 527, 641, 715, 832, 794, 865, 933]
                        }
                        ],
                        fill: {
                            type: ['solid', 'gradient', 'solid'],
                            gradient: {
                                shadeIntensity: 1,
                                type: "vertical",
                                inverseColors: false,
                                opacityFrom: 0.3,
                                opacityTo: 0.0,
                                stops: [20, 80, 100, 100]
                            },
                        },
                        grid: {
                            row: {
                                colors: ['transparent', 'transparent'], // takes an array which will be repeated on columns
                                opacity: 0.2
                            },
                            borderColor: '#f1f1f1'
                        },
                        xaxis: {
                            categories: [
                                "Jan",
                                "Feb",
                                "Mar",
                                "Apr",
                                "May",
                                "Jun",
                                "Jul",
                                "Aug",
                                "Sep",
                                "Oct",
                                "Nov",
                                "Dec",
                            ],
                        },
                        legend: {
                            position: 'top',
                            horizontalAlign: 'right',
                            floating: true,
                            offsetY: -25,
                            offsetX: -5
                        },
                        responsive: [{
                            breakpoint: 600,
                            options: {
                                chart: {
                                    toolbar: {
                                        show: false
                                    }
                                },
                                legend: {
                                    show: false
                                },
                            }
                        }]
                    }

                    var chart = new ApexCharts(
                        document.querySelector("#line_chart_datalabel"),
                        options
                    );
                    chart.render();
                }

                // world map with line & markers
                var vectorMapWorldLineColors = getChartColorsArray("world-map-line-markers");
                if (vectorMapWorldLineColors)
                    var worldlinemap = new jsVectorMap({
                        map: "world_merc",
                        selector: "#world-map-line-markers",
                        zoomOnScroll: false,
                        zoomButtons: false,
                        markers: [{
                            name: "Greenland",
                            coords: [71.7069, 42.6043],
                            style: {
                                image: "dashboard/assets/images/flags/gl.svg",
                            }
                        },
                        {
                            name: "Canada",
                            coords: [56.1304, -106.3468],
                            style: {
                                image: "dashboard/assets/images/flags/ca.svg",
                            }
                        },
                        {
                            name: "Brazil",
                            coords: [-14.2350, -51.9253],
                            style: {
                                image: "dashboard/assets/images/flags/br.svg",
                            }
                        },
                        {
                            name: "Serbia",
                            coords: [44.0165, 21.0059],
                            style: {
                                image: "dashboard/assets/images/flags/rs.svg",
                            }
                        },
                        {
                            name: "Russia",
                            coords: [61, 105],
                            style: {
                                image: "dashboard/assets/images/flags/ru.svg",
                            }
                        },
                        {
                            name: "US",
                            coords: [37.0902, -95.7129],
                            style: {
                                image: "dashboard/assets/images/flags/us.svg",
                            }
                        },
                        {
                            name: "Australia",
                            coords: [25.2744, 133.7751],
                            style: {
                                image: "dashboard/assets/images/flags/au.svg",
                            }
                        },
                        ],
                        lines: [{
                            from: "Canada",
                            to: "Serbia",
                        },
                        {
                            from: "Russia",
                            to: "Serbia"    
                        },
                        {
                            from: "Greenland",
                            to: "Serbia"
                        },
                        {
                            from: "Brazil",
                            to: "Serbia"
                        },
                        {
                            from: "US",
                            to: "Serbia"
                        },
                        {
                            from: "Australia",
                            to: "Serbia"
                        },
                        ],
                        regionStyle: {
                            initial: {
                                stroke: "#9599ad",
                                strokeWidth: 0.25,
                                fill: vectorMapWorldLineColors,
                                fillOpacity: 1,
                            },
                        },
                        labels: {
                            markers: {
                                render(marker, index) {
                                    return marker.name || marker.labelName || 'Not available'
                                }
                            }
                        },
                        lineStyle: {
                            animation: true,
                            strokeDasharray: "6 3 6",
                        },
                    });
                    

                    // Multi-Radial Bar
var chartRadialbarMultipleColors = getChartColorsArray("multiple_radialbar");
if (chartRadialbarMultipleColors) {
    var options = {
        series: [85, 69, 45, 78],
        chart: {
            height: 300,
            type: 'radialBar',
        },
        sparkline: {
            enabled: true
        },
        plotOptions: {
            radialBar: {
                startAngle: -90,
                endAngle: 90,
                dataLabels: {
                    name: {
                        fontSize: '22px',
                    },
                    value: {
                        fontSize: '16px',
                    },
                    total: {
                        show: true,
                        label: 'Sales',
                        formatter: function (w) {
                            return 2922
                        }
                    }
                }
            }
        },
        labels: ['Fashion', 'Electronics', 'Groceries', 'Others'],
        colors: chartRadialbarMultipleColors,
        legend: {
            show: false,
            fontSize: '16px',
            position: 'bottom',
            labels: {
                useSeriesColors: true,
            },
            markers: {
                size: 0
            },
        },
    };

    var chart = new ApexCharts(document.querySelector("#multiple_radialbar"), options);
    chart.render();
}


    //  Spline Area Charts
    var areachartSplineColors = getChartColorsArray("area_chart_spline");
    if (areachartSplineColors) {
        var options = {
            series: [{
                name: 'This Month',
                data: [49, 54, 48, 54, 67, 88, 96]
            }, {
                name: 'Last Month',
                data: [57, 66, 74, 63, 55, 70, 85]
            }],
            chart: {
                height: 250,
                type: 'area',
                toolbar: {
                    show: false
                }
            },
            fill: {
                type: ['gradient', 'gradient'],
                gradient: {
                    shadeIntensity: 1,
                    type: "vertical",
                    inverseColors: false,
                    opacityFrom: 0.3,
                    opacityTo: 0.0,
                    stops: [50, 70, 100, 100]
                },
            },
            markers: {
                size: 4,
                colors: "#ffffff",
                strokeColors: areachartSplineColors,
                strokeWidth: 1,
                strokeOpacity: 0.9,
                fillOpacity: 1,
                hover: {
                    size: 6,
                }
            },
            grid: {
                show: false,
                padding: {
                    top: -35,
                    right: 0,
                    bottom: 0,
                    left: -6,
                },
            },
             legend: {
                show: false, 
            },
            dataLabels: {
                enabled: false
            },
            stroke: {
                width: [2, 2],
                curve: 'smooth'
            },
            colors: areachartSplineColors,
            xaxis: {
                 labels: {
                    show: false,
                 }
            },
            yaxis: {
                labels: {
                    show: false,
                }
            },
        };

        var chart = new ApexCharts(document.querySelector("#area_chart_spline"), options);
        chart.render();
    }

        </script>
    </body>

</html>